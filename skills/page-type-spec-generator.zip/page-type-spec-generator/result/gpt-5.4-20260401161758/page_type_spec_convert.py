#!/usr/bin/env python3
import argparse
import json
import re
import shutil
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook


# DEVIATION: 一次性转换脚本，不做 IO 分层。

HEADER_ALIASES = {
    "namespce": "namespace",
    "Bolck role": "Block role",
}

ALLOWED_HEADERS = {
    "namespace",
    "category_id",
    "category_name",
    "category_description",
    "type_id",
    "type_name",
    "Block",
    "Block id",
    "Block description",
    "tag名称",
    "Block role",
    "tag编码",
    "tag定义",
    "tag anchor binding",
    "触发模式",
    "正例",
    "反例",
    "必须",
    "块摘要构造和输出组装",
    "采集和转化规范",
    "缺项处理",
    "冲突处理",
    "情景",
    "情景id",
    "阶段",
    "阶段id",
    "动作",
    "动作id",
}

FILL_DOWN_FIELDS = [
    "namespace",
    "category_id",
    "category_name",
    "category_description",
    "type_id",
    "type_name",
]

SEMANTIC_COLUMNS = [
    "tag定义",
    "触发模式",
    "正例",
    "反例",
    "必须",
    "tag anchor binding",
    "Block role",
]

OUTPUT_HINT_FILES = [
    "tagging-hint.md",
    "assembly-hint.md",
    "block-summary-hint.md",
    "page-summary-hint.md",
    "continuation-hint.md",
]


def clean(value):
    if value is None:
        return ""
    text = str(value).replace("\r\n", "\n").replace("\r", "\n").strip()
    return re.sub(r"[ \t]+", " ", text)


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, data):
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def write_text(path: Path, text: str):
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def normalize_header(raw_header):
    original = clean(raw_header)
    fixed = original
    repair_type = "exact_match"
    if fixed in ALLOWED_HEADERS:
        return fixed, repair_type
    trimmed = fixed.strip()
    if trimmed != fixed:
        fixed = trimmed
        repair_type = "trim_whitespace"
    spaced = re.sub(r"\s+", " ", fixed)
    if spaced != fixed:
        fixed = spaced
        repair_type = "normalize_spacing"
    if fixed in HEADER_ALIASES:
        return HEADER_ALIASES[fixed], "known_alias"
    if fixed in ALLOWED_HEADERS:
        return fixed, repair_type
    punct = fixed.replace("：", ":").replace("，", ",")
    if punct in ALLOWED_HEADERS:
        return punct, "normalize_punctuation"
    return original, "unrecognized_header"


def canonical_id(prefix, raw_value):
    text = clean(raw_value)
    if not text:
        return ""
    text = text.replace(".", "_")
    text = re.sub(r"[^0-9A-Za-z_]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_").upper()
    if not text:
        return ""
    if text.startswith(prefix):
        return text
    return prefix + text


def build_run_id():
    return datetime.now().strftime("run-%Y%m%d-%H%M%S")


def is_non_empty_row(values):
    return any(clean(v) for v in values)


def detect_header_row(rows):
    for idx, row in rows:
        values = [clean(v) for v in row]
        if "category_id" in values and "type_id" in values and "Block id" in values:
            return idx
    raise RuntimeError("未找到可识别的表头行")


def excel_col_label(index):
    label = ""
    while index > 0:
        index, rem = divmod(index - 1, 26)
        label = chr(65 + rem) + label
    return label


def load_raw_workbook(xlsx_path: Path):
    wb = load_workbook(xlsx_path, data_only=True)
    sheets = []
    indexed_rows = []
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        last_non_empty = 0
        for i, row in enumerate(rows, 1):
            if is_non_empty_row(row):
                last_non_empty = i
        sheet_rows = []
        for row_index, row in enumerate(rows[:last_non_empty], 1):
            if not is_non_empty_row(row):
                continue
            cells = []
            for col_index, value in enumerate(row, 1):
                if value is None:
                    continue
                cells.append(
                    {
                        "col_index": col_index,
                        "col_label": excel_col_label(col_index),
                        "raw_value": clean(value),
                    }
                )
            sheet_rows.append({"row_index": row_index, "cells": cells})
            indexed_rows.append((row_index, row))
        sheets.append({"name": ws.title, "rows": sheet_rows})
    header_row_index = detect_header_row(indexed_rows)
    return (
        {
            "workbook": {
                "path": str(xlsx_path),
                "sheet_names": [ws.title for ws in wb.worksheets],
                "header_row_index": header_row_index,
            },
            "sheets": sheets,
        },
        wb,
        header_row_index,
    )


def normalize_workbook(raw_data, wb, header_row_index):
    ws = wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    header_row = rows[header_row_index - 1]
    header_mapping = {}
    header_repairs = []
    normalized_headers = []
    for raw_header in header_row:
        normalized, repair_type = normalize_header(raw_header)
        original = clean(raw_header)
        if not original and not normalized:
            normalized_headers.append("")
            continue
        header_mapping[original] = normalized
        header_repairs.append(
            {
                "original_header": original,
                "normalized_header": normalized,
                "repair_type": repair_type,
            }
        )
        normalized_headers.append(normalized)

    inherited = {field: "" for field in FILL_DOWN_FIELDS}
    normalized_rows = []
    fill_records = []
    text_cleanups = []
    row_classification_summary = defaultdict(int)
    current_block = {"block_id": "", "block_name": "", "row_index": None}
    for row_index, raw_row in enumerate(rows[header_row_index:], header_row_index + 1):
        values = [clean(v) for v in raw_row]
        if not is_non_empty_row(values):
            continue
        record = {}
        for i, normalized_header in enumerate(normalized_headers):
            if not normalized_header:
                continue
            record[normalized_header] = values[i] if i < len(values) else ""
        original_record = dict(record)
        for field in FILL_DOWN_FIELDS:
            value = record.get(field, "")
            if value:
                inherited[field] = value
            elif inherited[field]:
                record[field] = inherited[field]
                fill_records.append(
                    {
                        "row_index": row_index,
                        "field": field,
                        "filled_value": inherited[field],
                    }
                )
        for key, value in list(record.items()):
            cleaned = clean(value)
            if cleaned != value:
                text_cleanups.append(
                    {"row_index": row_index, "field": key, "from": value, "to": cleaned}
                )
                record[key] = cleaned
        row_kind = classify_row(record)
        row_classification_summary[row_kind] += 1
        if record.get("Block id"):
            current_block = {
                "block_id": canonical_id("BLOCK_", record.get("Block id")),
                "block_name": record.get("Block", ""),
                "row_index": row_index,
            }
        normalized_rows.append(
            {
                "row_index": row_index,
                "fields": record,
                "original_fields": original_record,
                "row_kind": row_kind,
                "current_block": current_block,
            }
        )

    normalized = {
        "header_mapping": header_mapping,
        "header_repairs": header_repairs,
        "inherit_fill_records": fill_records,
        "text_cleanup_records": text_cleanups,
        "rows": normalized_rows,
    }

    report_lines = [
        "# Normalization Report",
        "",
        "## 表头修复摘要",
    ]
    for repair in header_repairs:
        report_lines.append(
            f"- row {header_row_index}: `{repair['original_header']}` -> `{repair['normalized_header']}` ({repair['repair_type']})"
        )
    report_lines.extend(["", "## 继承填充摘要"])
    if fill_records:
        for item in fill_records:
            report_lines.append(
                f"- row {item['row_index']}: `{item['field']}` 继承为 `{item['filled_value']}`"
            )
    else:
        report_lines.append("- 无")
    report_lines.extend(["", "## 文本清洗摘要"])
    if text_cleanups:
        for item in text_cleanups[:20]:
            report_lines.append(
                f"- row {item['row_index']}: `{item['field']}` 做了轻清洗"
            )
    else:
        report_lines.append("- 无")
    report_lines.extend(["", "## 行分类摘要"])
    for key in ["empty", "block_start", "tag_candidate", "helper_candidate", "unknown"]:
        report_lines.append(f"- `{key}`: {row_classification_summary.get(key, 0)}")
    return normalized, "\n".join(report_lines)


def classify_row(fields):
    values = [clean(v) for v in fields.values()]
    if not any(values):
        return "empty"
    if clean(fields.get("Block id")):
        return "block_start"
    tag_name = clean(fields.get("tag名称"))
    if tag_name and any(
        clean(fields.get(col))
        for col in [
            "tag编码",
            "tag定义",
            "tag anchor binding",
            "触发模式",
            "正例",
            "反例",
            "必须",
            "Block role",
        ]
    ):
        return "tag_candidate"
    if (not tag_name) and (
        clean(fields.get("Block role")) or clean(fields.get("Block description"))
    ):
        return "helper_candidate"
    return "unknown"


def build_identity_map(normalized, mode, selected_types):
    types = {}
    identity_issues = []
    namespace = ""
    explicit_tags_by_type = defaultdict(dict)

    for row in normalized["rows"]:
        fields = row["fields"]
        if fields.get("namespace") and not namespace:
            namespace = fields["namespace"]
        type_id = canonical_id("TYPE_", fields.get("type_id"))
        if not type_id:
            continue
        if type_id not in types:
            types[type_id] = {
                "type_id": type_id,
                "type_name": fields.get("type_name", ""),
                "category": {
                    "id": canonical_id("CATEGORY_", fields.get("category_id")),
                    "name": fields.get("category_name", ""),
                    "description": fields.get("category_description", ""),
                },
                "blocks": {},
                "tags": {},
                "source_rows": [],
            }
        types[type_id]["source_rows"].append(row["row_index"])

        block_id = canonical_id("BLOCK_", fields.get("Block id"))
        if block_id:
            block = types[type_id]["blocks"].setdefault(
                block_id,
                {
                    "id": block_id,
                    "name": fields.get("Block", ""),
                    "source_rows": [],
                    "description_source": fields.get("Block description", ""),
                    "tag_refs": [],
                },
            )
            block["source_rows"].append(row["row_index"])

        tag_name = clean(fields.get("tag名称"))
        tag_code = clean(fields.get("tag编码"))
        block_context = row.get("current_block") or {}
        if tag_name or tag_code:
            status = resolve_tag_status(fields)
            if status == "invalid_or_noise":
                identity_issues.append(
                    f"- row {row['row_index']}: 标签行无有效语义，标记为 invalid_or_noise"
                )
                continue

            canonical_tag_id, merge_reason = resolve_tag_id(
                fields, types[type_id]["tags"], explicit_tags_by_type[type_id]
            )
            if tag_code:
                explicit_tags_by_type[type_id][canonical_tag_id] = fields

            tag_entry = types[type_id]["tags"].setdefault(
                canonical_tag_id,
                {
                    "canonical_id": canonical_tag_id,
                    "name": tag_name or fields.get("tag定义", "") or canonical_tag_id,
                    "identity_status": status,
                    "source_rows": [],
                    "rows": [],
                    "merged_rows": [],
                },
            )
            tag_entry["source_rows"].append(row["row_index"])
            tag_entry["rows"].append({"row_index": row["row_index"], "fields": fields})
            if merge_reason:
                tag_entry["merged_rows"].append(
                    {"row_index": row["row_index"], "reason": merge_reason}
                )
                identity_issues.append(
                    f"- row {row['row_index']}: 空 `tag编码` 行并入 `{canonical_tag_id}` ({merge_reason})"
                )
            elif status == "recoverable_tag":
                identity_issues.append(
                    f"- row {row['row_index']}: 空 `tag编码` 行保留为 recoverable_tag，并生成 `{canonical_tag_id}`"
                )

            if block_context and block_context.get("block_id"):
                block = types[type_id]["blocks"].setdefault(
                    block_context["block_id"],
                    {
                        "id": block_context["block_id"],
                        "name": block_context.get("block_name", ""),
                        "source_rows": [block_context.get("row_index")],
                        "description_source": "",
                        "tag_refs": [],
                    },
                )
                ref = {
                    "tag_id": canonical_tag_id,
                    "role": clean(fields.get("Block role")),
                    "source_row": row["row_index"],
                }
                if ref not in block["tag_refs"]:
                    block["tag_refs"].append(ref)

    detected_types = sorted(types.keys())
    if not namespace:
        namespace = "default"
    identity_map = {
        "namespace": namespace,
        "types": types,
        "detected_type_ids": detected_types,
        "selected_type_ids": selected_types,
    }
    issues = ["# Identity Issues", "", "## 空 `tag编码` 行处理记录"]
    issues.extend(identity_issues or ["- 无"])
    issues.extend(["", "## 身份冲突记录", "- 无", "", "## 未决身份问题"])
    unresolved = []
    if len(detected_types) > 1 and not selected_types and mode == "interactive":
        unresolved.append(
            f"- 检测到多个 type: {', '.join(detected_types)}；需要用户选择处理范围。"
        )
    issues.extend(unresolved or ["- 无"])
    return identity_map, "\n".join(issues)


def resolve_tag_status(fields):
    tag_name = clean(fields.get("tag名称"))
    tag_code = clean(fields.get("tag编码"))
    semantic = any(clean(fields.get(col)) for col in SEMANTIC_COLUMNS)
    if tag_name and tag_code:
        return "explicit_tag"
    if tag_name and not tag_code and semantic:
        return "recoverable_tag"
    if (not tag_name) and clean(fields.get("Block role")) and not semantic:
        return "helper_only"
    return "invalid_or_noise"


def resolve_tag_id(fields, existing_tags, explicit_tags):
    tag_code = clean(fields.get("tag编码"))
    tag_name = clean(fields.get("tag名称"))
    role = clean(fields.get("Block role"))
    if tag_code:
        return canonical_id("TAG_", tag_code), ""

    for tag_id, explicit in explicit_tags.items():
        if clean(explicit.get("tag名称")) == tag_name:
            return tag_id, "matched explicit tag by name"

    if role == "record_time_source" and "TAG_RECORD_TIME" in explicit_tags:
        return (
            "TAG_RECORD_TIME",
            "record_time_source merged into explicit record time tag",
        )

    generated = canonical_id("TAG_", tag_name)
    if generated in existing_tags:
        return generated, "reused stable canonical id by tag name"
    return generated, ""


def parse_anchor_binding(text, repair_log, issue_log):
    raw = clean(text)
    if not raw:
        return None
    original = raw
    fixed = raw.replace("with_type_run", "within_type_run")
    if fixed != raw:
        repair_log.append({"from": raw, "to": fixed, "repair_type": "known_alias"})
    raw = fixed

    target_match = re.search(r"target_tag_ids\s*:\s*\[(.*?)\]", raw, re.S)
    target_ids = []
    if target_match:
        target_ids = re.findall(r"TAG_[A-Z0-9_]+", target_match.group(1).upper())
    mode_match = re.search(
        r"page_window\.mode\s*:\s*\{?\s*\"?([a-zA-Z_]+)\"?\s*\}?", raw
    )
    mode = mode_match.group(1) if mode_match else "within_type_run"
    direction_match = re.search(r"direction\s*:\s*\"?([a-zA-Z_]+)\"?", raw)
    direction = direction_match.group(1) if direction_match else ""
    required_match = re.search(r"required\s*:\s*(true|false)", raw, re.I)
    required = required_match.group(1).lower() == "true" if required_match else True
    self_match = re.search(r"self_resolution\s*:\s*\"?([a-zA-Z_]+)\"?", raw)
    self_resolution = self_match.group(1) if self_match else "direction_only"
    prev_match = re.search(r"prev\s*:\s*(\d+)", raw)
    next_match = re.search(r"next\s*:\s*(\d+)", raw)

    mode = "within_type_run" if mode == "with_type_run" else mode
    binding = {
        "target_tag_ids": target_ids,
        "page_window": {"mode": mode or "within_type_run"},
        "direction": direction,
        "required": required,
        "self_resolution": self_resolution or "direction_only",
    }
    if binding["page_window"]["mode"] == "bounded":
        if prev_match and next_match:
            binding["page_window"]["prev"] = int(prev_match.group(1))
            binding["page_window"]["next"] = int(next_match.group(1))
        else:
            issue_log.append(
                f"anchor_binding 缺少 bounded 模式的 prev/next: {original}"
            )
    if not binding["target_tag_ids"]:
        issue_log.append(f"anchor_binding 缺少 target_tag_ids: {original}")
    if not binding["direction"]:
        issue_log.append(f"anchor_binding 缺少 direction: {original}")
    return binding


def short_pattern_hint(trigger_text):
    text = clean(trigger_text)
    if not text:
        return ""
    if "时间" in text:
        return "优先匹配能够直接表达时间或时长的文本。"
    if "关键词匹配" in text or "关键字匹配" in text or "匹配" in text:
        return "优先匹配能够稳定指向该语义的关键词或短语。"
    return "优先匹配能直接表达该语义的稳定表述。"


def negative_rule(negative_text, required_flag):
    text = clean(negative_text)
    if not text or any(
        key in text for key in ["未提及", "未说明", "未见", "无", "缺如"]
    ):
        return (
            "原文未提供稳定可判定内容时不打本标签。"
            if required_flag
            else "原文未提供稳定可判定内容时可留空。"
        )
    return "排除只表达其他语义角色、背景信息或无法稳定落到本标签边界的内容。"


def output_rule_for_tag(tag_name, tag_definition, required_flag):
    merged = f"{tag_name} {tag_definition}"
    if "时间" in merged:
        return "输出单值，优先规范化为 YYYY-MM-DD、YYYY-MM-DD HH:mm 或 YYYY-MM-DD HH:mm:ss；无法规范化时不打本标签。"
    if "症状" in merged or "诊断" in merged or "部位" in merged or "原因" in merged:
        return "输出单值，保留原文中最稳定、最直接的表达。"
    return (
        "输出单值，保留原文中能够稳定承载该语义的最小必要表达。"
        if required_flag
        else "输出单值；无稳定值时可留空。"
    )


def generate_value_hint(fields):
    definition = clean(fields.get("tag定义"))
    required_flag = clean(fields.get("必须")) == "是"
    sentences = []
    if definition:
        sentences.append(definition.rstrip("。") + "。")
    pattern = short_pattern_hint(fields.get("触发模式"))
    if pattern:
        sentences.append(pattern)
    sentences.append(negative_rule(fields.get("反例"), required_flag))
    sentences.append(
        output_rule_for_tag(fields.get("tag名称", ""), definition, required_flag)
    )
    return "".join(sentences)


def generate_context_hint(tag_id, fields):
    tag_name = clean(fields.get("tag名称"))
    definition = clean(fields.get("tag定义"))
    if tag_id == "TAG_RECORD_TIME":
        return "明确当前时间值是在断言记录时间、入院时间还是报告时间。"
    if "时间" in tag_name and any(
        word in definition for word in ["入院", "报告", "记录"]
    ):
        return "补充时间所对应的事件或语义角色。"
    return ""


def generate_block_description(block, tag_names):
    description = clean(block.get("description_source"))
    if description:
        return description.rstrip("。") + "。"
    dims = "、".join(tag_names[:6])
    return f"该块表达{block.get('name', '')}相关信息，覆盖{dims}等语义维度。"


def render_tagging_hint(type_name, type_rows):
    rules = []
    for row in type_rows:
        anti = clean(row.get("反例"))
        collect = clean(row.get("采集和转化规范"))
        if anti and not any(key in anti for key in ["未提及", "未说明", "无"]):
            rules.append(
                "- 区分相邻标签时，优先按标签定义边界判断，避免把背景信息或其他语义角色误打到当前标签。"
            )
            break
        if collect and any(
            key in collect for key in ["去重", "标准化", "保留原", "单位"]
        ):
            rules.append(
                "- 段内取值先做轻量规范化，再保留原文可回溯性，避免因为局部排版噪声造成误标。"
            )
            break
    if not rules:
        return f"# {type_name} · 段打标处理指导\n\n<!-- TODO: 当前设计稿未提供专门的段打标补充规则 -->"
    return f"# {type_name} · 段打标处理指导\n\n## 通用规则\n" + "\n".join(
        dict.fromkeys(rules)
    )


def render_grouped_hint(type_name, type_rows, title, empty_comment, columns):
    sections = []
    mapping = {
        "采集和转化规范": "## 采集与规范化",
        "缺项处理": "## 缺项处理",
        "冲突处理": "## 冲突处理",
        "块摘要构造和输出组装": "## 摘要重点",
    }
    for column in columns:
        values = []
        for row in type_rows:
            value = clean(row.get(column))
            if value:
                values.append(value)
        if not values:
            continue
        unique_values = list(dict.fromkeys(values))
        bullet_lines = [f"- {v.replace(chr(10), '；')}" for v in unique_values]
        sections.append(mapping[column] + "\n" + "\n".join(bullet_lines))
    if not sections:
        return f"# {type_name} · {title}\n\n<!-- TODO: {empty_comment} -->"
    return f"# {type_name} · {title}\n\n" + "\n\n".join(sections)


def build_outputs(identity_map, normalized, selected_types, output_root, run_manifest):
    intermediate_dir = output_root / "intermediate"
    skeleton_dir = intermediate_dir / "skeleton"
    semantic_dir = intermediate_dir / "semantic-draft"
    final_dir = output_root / "final" / identity_map["namespace"]
    for path in [skeleton_dir, semantic_dir, final_dir]:
        ensure_dir(path)

    types_data = {
        "version": "1.0.0",
        "description": "Generated from workbook by page_type_spec_convert.py",
        "last_updated": date.today().isoformat(),
        "categories": [],
    }
    categories = {}
    validation_errors = []
    validation_warnings = []
    audit_lines = [
        "# Audit Report",
        "",
        "## 输入摘要",
        f"- 输入文件: `{run_manifest['input_files'][0]['path']}`",
        f"- 检测到的 type: {', '.join(run_manifest['detected_types'])}",
        f"- 选中的 type: {', '.join(selected_types)}",
        "",
        "## 自动修复摘要",
    ]

    all_rows_by_type = defaultdict(list)
    for row in normalized["rows"]:
        type_id = canonical_id("TYPE_", row["fields"].get("type_id"))
        if type_id:
            all_rows_by_type[type_id].append(row["fields"])

    for type_id in selected_types:
        type_info = identity_map["types"][type_id]
        cat = type_info["category"]
        category_entry = categories.setdefault(
            cat["id"],
            {
                "id": cat["id"],
                "name": cat["name"],
                "description": cat["description"],
                "types": [],
            },
        )
        category_entry["types"].append({"id": type_id, "name": type_info["type_name"]})

        tag_repairs = []
        tag_issues = []
        root_tags = []
        for tag_id, tag in sorted(type_info["tags"].items()):
            source_fields = tag["rows"][0]["fields"]
            tag_obj = {
                "id": tag_id,
                "name": clean(source_fields.get("tag名称")) or tag["name"],
                "value_hint": generate_value_hint(source_fields),
            }
            context_hint = generate_context_hint(tag_id, source_fields)
            if context_hint:
                tag_obj["context_hint"] = context_hint
            anchor_binding = parse_anchor_binding(
                source_fields.get("tag anchor binding"), tag_repairs, tag_issues
            )
            if anchor_binding:
                tag_obj["anchor_binding"] = anchor_binding
            root_tags.append(tag_obj)

        block_types = []
        for block_id, block in sorted(type_info["blocks"].items()):
            block_tag_names = [
                next(
                    (
                        tag["name"]
                        for tid, tag in type_info["tags"].items()
                        if tid == ref["tag_id"]
                    ),
                    ref["tag_id"],
                )
                for ref in block["tag_refs"]
            ]
            block_entry = {
                "id": block_id,
                "name": block["name"],
                "tags": [],
            }
            block_entry["description"] = generate_block_description(
                block, block_tag_names
            )
            seen = set()
            for ref in block["tag_refs"]:
                key = (ref["tag_id"], ref.get("role", ""))
                if key in seen:
                    continue
                seen.add(key)
                item = {"tag_id": ref["tag_id"]}
                if ref.get("role"):
                    item["role"] = ref["role"]
                block_entry["tags"].append(item)
            block_types.append(block_entry)

        spec = {
            "version": "1.0.0",
            "page_type": {"id": type_id, "name": type_info["type_name"]},
            "block_types": block_types,
            "tags": root_tags,
        }

        type_skeleton_dir = skeleton_dir / identity_map["namespace"] / "types" / type_id
        type_semantic_dir = semantic_dir / identity_map["namespace"] / "types" / type_id
        type_final_dir = final_dir / "types" / type_id
        for path in [type_skeleton_dir, type_semantic_dir, type_final_dir]:
            ensure_dir(path)
        empty_spec = {
            "version": spec["version"],
            "page_type": spec["page_type"],
            "block_types": [
                {"id": b["id"], "name": b["name"], "tags": b["tags"]}
                for b in block_types
            ],
            "tags": [
                {"id": t["id"], "name": t["name"], "value_hint": "TODO"}
                for t in root_tags
            ],
        }
        write_json(type_skeleton_dir / "page-semantic-spec.json", empty_spec)
        write_json(type_semantic_dir / "page-semantic-spec.json", spec)
        write_json(type_final_dir / "page-semantic-spec.json", spec)

        type_rows = all_rows_by_type[type_id]
        hint_payloads = {
            "tagging-hint.md": render_tagging_hint(type_info["type_name"], type_rows),
            "assembly-hint.md": render_grouped_hint(
                type_info["type_name"],
                type_rows,
                "块组装处理指导",
                "当前设计稿未提供专门的块组装规则",
                ["采集和转化规范", "缺项处理", "冲突处理"],
            ),
            "block-summary-hint.md": render_grouped_hint(
                type_info["type_name"],
                type_rows,
                "块摘要生成指导",
                "当前设计稿未提供专门的块摘要规则",
                ["块摘要构造和输出组装", "采集和转化规范", "缺项处理", "冲突处理"],
            ),
            "page-summary-hint.md": f"# {type_info['type_name']} · 页摘要生成指导\n\n<!-- TODO: 当前设计稿未提供专门的页摘要规则 -->",
            "continuation-hint.md": f"# {type_info['type_name']} · 续写判定提示\n\n<!-- TODO: 当前设计稿未提供专门的续写规则 -->",
        }
        for filename, payload in hint_payloads.items():
            write_text(
                type_skeleton_dir / filename,
                payload
                if filename in ["page-summary-hint.md", "continuation-hint.md"]
                else f"# {type_info['type_name']}\n\n<!-- TODO: skeleton placeholder -->",
            )
            write_text(type_semantic_dir / filename, payload)
            write_text(type_final_dir / filename, payload)

        for repair in tag_repairs:
            audit_lines.append(
                f"- anchor_binding 自动修复: `{repair['from']}` -> `{repair['to']}` ({repair['repair_type']})"
            )
        for issue in tag_issues:
            validation_warnings.append({"type_id": type_id, "message": issue})

        validate_type_spec(spec, validation_errors, validation_warnings, type_id)

    types_data["categories"] = list(categories.values())
    page_types_tree = json.loads(json.dumps(types_data, ensure_ascii=False))
    for base in [
        skeleton_dir / identity_map["namespace"],
        semantic_dir / identity_map["namespace"],
        final_dir,
    ]:
        ensure_dir(base)
        write_json(base / "page-types.data.json", types_data)
        write_json(base / "page-types.tree.json", page_types_tree)

    validate_page_types(
        types_data, validation_errors, validation_warnings, "page-types.data.json"
    )
    validate_page_types(
        page_types_tree, validation_errors, validation_warnings, "page-types.tree.json"
    )

    validation_report = {
        "status": "passed" if not validation_errors else "failed",
        "structure_validation": "passed" if not validation_errors else "failed",
        "reference_closure": "passed"
        if not any(e for e in validation_errors if "reference" in e.get("kind", ""))
        else "failed",
        "artifact_completeness": "passed",
        "errors": validation_errors,
        "warnings": validation_warnings,
    }
    write_json(output_root / "validation-report.json", validation_report)

    audit_lines.extend(
        [
            "",
            "## 身份问题摘要",
            "- 空 `tag编码` 行已进入身份解析，并在 `identity-issues.md` 留痕。",
            "",
            "## 结构校验摘要",
            f"- 失败项: {len(validation_errors)}",
            f"- 警告项: {len(validation_warnings)}",
            "",
            "## 未决问题摘要",
        ]
    )
    if validation_warnings:
        for warning in validation_warnings:
            audit_lines.append(f"- {warning['type_id']}: {warning['message']}")
    else:
        audit_lines.append("- 无")
    write_text(output_root / "audit-report.md", "\n".join(audit_lines))

    final_lines = [
        "# Final Report",
        "",
        "## 处理范围",
        f"- 处理的 type: {', '.join(selected_types)}",
        "",
        "## 生成文件",
        f"- 中间产物目录: `{intermediate_dir}`",
        f"- 最终交付目录: `{final_dir}`",
        f"- 校验报告: `{output_root / 'validation-report.json'}`",
        f"- 审计报告: `{output_root / 'audit-report.md'}`",
        "",
        "## 自动决策",
        "- 使用 skill 自带 `rules/*` 与 `schema/*` 执行转换。",
        "- 对空 `tag编码` 行执行了保留或并入，不做静默丢弃。",
        "- `page-summary-hint.md` 与 `continuation-hint.md` 因缺少专门素材输出空模板。",
        "",
        "## 剩余风险",
    ]
    if validation_warnings:
        for warning in validation_warnings:
            final_lines.append(f"- {warning['type_id']}: {warning['message']}")
    else:
        final_lines.append("- 无阻塞风险。")
    write_text(output_root / "final-report.md", "\n".join(final_lines))
    return intermediate_dir, final_dir


def validate_page_types(data, errors, warnings, filename):
    required = ["version", "description", "last_updated", "categories"]
    for field in required:
        if field not in data:
            errors.append(
                {
                    "file": filename,
                    "kind": "schema",
                    "message": f"missing field `{field}`",
                }
            )
    if not isinstance(data.get("categories"), list):
        errors.append(
            {
                "file": filename,
                "kind": "schema",
                "message": "`categories` must be array",
            }
        )
        return
    for category in data.get("categories", []):
        if not isinstance(category.get("types"), list):
            errors.append(
                {
                    "file": filename,
                    "kind": "schema",
                    "message": f"category `{category.get('id', '')}` types must be array",
                }
            )


def validate_type_spec(spec, errors, warnings, type_id):
    if "page_type" not in spec or "id" not in spec["page_type"]:
        errors.append(
            {"file": type_id, "kind": "schema", "message": "missing `page_type.id`"}
        )
    tag_ids = {tag["id"] for tag in spec.get("tags", [])}
    if len(tag_ids) != len(spec.get("tags", [])):
        errors.append(
            {
                "file": type_id,
                "kind": "reference_closure",
                "message": "duplicate root tag ids",
            }
        )
    block_ids = [block["id"] for block in spec.get("block_types", [])]
    if len(block_ids) != len(set(block_ids)):
        errors.append(
            {
                "file": type_id,
                "kind": "reference_closure",
                "message": "duplicate block ids",
            }
        )
    for block in spec.get("block_types", []):
        for ref in block.get("tags", []):
            if ref["tag_id"] not in tag_ids:
                errors.append(
                    {
                        "file": type_id,
                        "kind": "reference_closure",
                        "message": f"block `{block['id']}` references missing tag `{ref['tag_id']}`",
                    }
                )
    for tag in spec.get("tags", []):
        if not tag.get("value_hint"):
            errors.append(
                {
                    "file": type_id,
                    "kind": "schema",
                    "message": f"tag `{tag['id']}` missing `value_hint`",
                }
            )
        anchor = tag.get("anchor_binding")
        if anchor:
            if not anchor.get("target_tag_ids"):
                warnings.append(
                    {
                        "type_id": type_id,
                        "message": f"{tag['id']} anchor_binding 缺少 target_tag_ids",
                    }
                )
            if not anchor.get("direction"):
                warnings.append(
                    {
                        "type_id": type_id,
                        "message": f"{tag['id']} anchor_binding 缺少 direction",
                    }
                )


def build_run_manifest(
    run_id, input_file, mode, detected_types=None, selected_types=None
):
    return {
        "run_id": run_id,
        "mode": mode,
        "input_files": [{"path": str(input_file), "exists": input_file.exists()}],
        "provided_page_types_data": False,
        "provided_page_types_tree": False,
        "detected_types": detected_types or [],
        "selected_types": selected_types or [],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("xlsx")
    parser.add_argument("--output-root", required=True)
    parser.add_argument(
        "--mode",
        default="interactive",
        choices=["interactive", "constrained", "no_interaction"],
    )
    parser.add_argument("--types", nargs="*")
    args = parser.parse_args()

    xlsx_path = Path(args.xlsx).resolve()
    output_root = Path(args.output_root).resolve()
    if output_root.exists():
        shutil.rmtree(output_root)
    ensure_dir(output_root)
    intermediate_dir = output_root / "intermediate"
    ensure_dir(intermediate_dir)

    run_id = build_run_id()
    run_manifest = build_run_manifest(run_id, xlsx_path, args.mode)
    write_json(intermediate_dir / "run-manifest.json", run_manifest)

    raw_data, wb, header_row_index = load_raw_workbook(xlsx_path)
    write_json(intermediate_dir / "workbook.raw.json", raw_data)

    normalized, normalization_report = normalize_workbook(
        raw_data, wb, header_row_index
    )
    write_json(intermediate_dir / "workbook.normalized.json", normalized)
    write_text(intermediate_dir / "normalization-report.md", normalization_report)

    selected_types = [canonical_id("TYPE_", item) for item in (args.types or [])]
    identity_map, identity_issues = build_identity_map(
        normalized, args.mode, selected_types
    )
    write_json(intermediate_dir / "identity-map.json", identity_map)
    write_text(intermediate_dir / "identity-issues.md", identity_issues)

    detected_types = identity_map["detected_type_ids"]
    run_manifest = build_run_manifest(
        run_id, xlsx_path, args.mode, detected_types, selected_types
    )
    write_json(intermediate_dir / "run-manifest.json", run_manifest)

    if not selected_types:
        if len(detected_types) == 1:
            selected_types = detected_types
        elif args.mode == "no_interaction":
            selected_types = detected_types
            run_manifest["selected_types"] = selected_types
            write_json(intermediate_dir / "run-manifest.json", run_manifest)
        else:
            print(
                json.dumps(
                    {
                        "status": "needs_type_selection",
                        "detected_types": detected_types,
                        "intermediate_dir": str(intermediate_dir),
                    },
                    ensure_ascii=False,
                )
            )
            return

    run_manifest["selected_types"] = selected_types
    write_json(intermediate_dir / "run-manifest.json", run_manifest)
    intermediate_dir, final_dir = build_outputs(
        identity_map, normalized, selected_types, output_root, run_manifest
    )
    print(
        json.dumps(
            {
                "status": "completed",
                "intermediate_dir": str(intermediate_dir),
                "final_dir": str(final_dir),
                "validation_report": str(output_root / "validation-report.json"),
                "audit_report": str(output_root / "audit-report.md"),
                "final_report": str(output_root / "final-report.md"),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
