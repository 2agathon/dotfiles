# Final Report

## 处理范围
- 处理的 type: TYPE_ADMISSION_RECORD

## 生成文件
- 中间产物目录: `D:\data\save_tmp\page-type-spec-output\admission-chief-present-history\intermediate`
- 最终交付目录: `D:\data\save_tmp\page-type-spec-output\admission-chief-present-history\final\default`
- 校验报告: `D:\data\save_tmp\page-type-spec-output\admission-chief-present-history\validation-report.json`
- 审计报告: `D:\data\save_tmp\page-type-spec-output\admission-chief-present-history\audit-report.md`

## 自动决策
- 使用 skill 自带 `rules/*` 与 `schema/*` 执行转换。
- 对空 `tag编码` 行执行了保留或并入，不做静默丢弃。
- `page-summary-hint.md` 与 `continuation-hint.md` 因缺少专门素材输出空模板。

## 剩余风险
- 无阻塞风险。
