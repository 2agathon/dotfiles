# 入院记录

<!-- TODO: skeleton placeholder -->
