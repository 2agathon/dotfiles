# final-report

## 处理范围
- type: `TYPE_ADMISSION_RECORD` / 入院记录

## 生成文件
- final dir: `D:\data\save_tmp\ptsg-output\default`
- `D:\data\save_tmp\ptsg-output\default\page-types.data.json`
- `D:\data\save_tmp\ptsg-output\default\page-types.tree.json`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\page-semantic-spec.json`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\tagging-hint.md`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\assembly-hint.md`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\block-summary-hint.md`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\page-summary-hint.md`
- `D:\data\save_tmp\ptsg-output\default\types\TYPE_ADMISSION_RECORD\continuation-hint.md`

## 自动决策
- page-types.data.json 与 page-types.tree.json 目前使用同一 taxonomy 载荷，以满足同一 schema 约束。
- 页摘要与续写提示因当前设计稿无专门素材，按规则输出空模板。
- 空 tag编码 的时间源标签按稳定 role token 恢复为可复用 ID。

## 剩余风险
- 无额外风险。

## 占位符对象
- 无

## Validation 状态
- `passed`
