# identity-issues

## 空 tag编码 行处理记录
- row 8: `入院日期` in `BLOCK_ADMISSION_CHIEF_COMPLAINT` entered recovery flow
- row 24: `入院日期` in `BLOCK_ADMISSION_PRESENT_ILLNESS` entered recovery flow
- row 40: `入院日期` in `BLOCK_ADMISSION_PAST_MEDICAL_HISTORY` entered recovery flow
- row 51: `入院日期` in `BLOCK_ADMISSION_EXAMINATION_FINDINGS` entered recovery flow
- row 57: `入院日期` in `BLOCK_ADMISSION_MEDICAL_NECESSITY_ASSESSMENT` entered recovery flow
- row 65: `入院日期` in `BLOCK_ADMISSION_PRELIMINARY_DIAGNOSIS` entered recovery flow
- row 70: `入院日期` in `BLOCK_ADMISSION_DIAGNOSIS` entered recovery flow
- row 81: `入院日期` in `BLOCK_ADMISSION_TREATMENT_PLAN` entered recovery flow
- row 88: `报告时间` in `BLOCK_LABORATORY_TEST_ITEMS` entered recovery flow
- row 96: `报告时间` in `BLOCK_LABORATORY_ABNORMAL_AND_CRITICAL_VALUES` entered recovery flow

## 占位符生成记录
- 无

## 身份冲突
- 无

## blocked 对象
- 无
