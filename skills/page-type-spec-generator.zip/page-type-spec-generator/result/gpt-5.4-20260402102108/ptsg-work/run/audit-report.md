# audit-report

## 输入摘要
- 输入文件: `入院记录-主诉与现病史结构化解析.xlsx`
- 选中 type: `TYPE_ADMISSION_RECORD` / 入院记录
- 选中 block 数: 8
- 选中 tag 数: 58

## 自动修复摘要
- header A: `namespce` -> `namespace` (known_alias)
- header G: `一级要点` -> `一级要点` (unrecognized_header)
- header H: `主线索` -> `主线索` (unrecognized_header)
- header S: `Bolck role` -> `Block role` (known_alias)
- TAG_ADMISSION_COMPLAINT_DURATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_COMPLAINT_QUALIFIER: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_COMPLAINT_BODY_PART: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_COMPLAINT_IMPACT_FACTOR: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_RECORD_TIME_SOURCE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_RECORD_TIME: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_ADMIT_REASON: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_ONSET_TIME: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_ONSET_MODE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_TRIGGER: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_SYMPTOM: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_SEVERITY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_ASSOCIATED_SYMPTOM: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_NEGATIVE_SYMPTOM: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_PROGRESSION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_CONDITION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_PRIOR_TREATMENT: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_TREATMENT_RESPONSE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PRESENT_EXTERNAL_EXAM: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_DURATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_CONTROL: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_PANDEMIC: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_MEDICATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_SURGERY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_TRAUMA: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_TRANSFUSION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_PERSONAL: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_FAMILY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_ALLERGY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_ALLERGY_SYMPTOMS: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_MENSTRUAL: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_HISTORY_OBSTETRIC: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_GENERAL_STATE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_POSITIVE_SIGN: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_NEGATIVE_SIGN: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_LABORATORY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_IMAGING: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_ENDOSCOPY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_PATHOLOGY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_EXAM_FUNCTION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_ASSESSMENT_NUTRITIONAL: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_ASSESSMENT_FUNCTION_NEEDS: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_ASSESSMENT_PSYCHOLOGICAL: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_ADMISSION_UNCERTAINTY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_ADMISSION_ETIOLOGY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_ADMISSION_PATHOLOGY: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_ADMISSION_TYPING: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_ADMISSION_COMPLICATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_INITIAL_SECONDARY_DISEASE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_DIAGNOSIS_INITIAL_DIAGNOSTIC_BASIS: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_EXAM_IMAGE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_EXAM_OTHER: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_TREATMENT_MEDICATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_TREATMENT_PROCEDURE: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_MONITOR: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_NURSING: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_EDUCATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]
- TAG_ADMISSION_PLAN_CONSULTATION: [{"repair_type": "known_alias", "from": "with_type_run", "to": "within_type_run"}]

## 身份问题摘要
- row 8: `入院日期` entered recovery flow
- row 24: `入院日期` entered recovery flow
- row 40: `入院日期` entered recovery flow
- row 51: `入院日期` entered recovery flow
- row 57: `入院日期` entered recovery flow
- row 65: `入院日期` entered recovery flow
- row 70: `入院日期` entered recovery flow
- row 81: `入院日期` entered recovery flow
- row 88: `报告时间` entered recovery flow
- row 96: `报告时间` entered recovery flow

## 结构校验摘要
- status: `passed`

## 未决问题摘要
- 无

## 占位符摘要
- placeholder tags: 无

## 类型污染检查摘要
- 结果: 通过
