# normalization-report

## 表头修复摘要
- 检测到表头行: 2
- 表头修复数: 4
- A: `namespce` -> `namespace` (known_alias)
- G: `一级要点` -> `一级要点` (unrecognized_header)
- H: `主线索` -> `主线索` (unrecognized_header)
- S: `Bolck role` -> `Block role` (known_alias)

## 继承填充摘要
- 继承填充数: 962

## 文本清洗摘要
- 已统一换行并裁剪首尾空白。

## 行分类摘要
- block_start: 10
- tag_candidate: 84

## 预表头行
- 已保留于 raw parse，未纳入 normalized rows: [1]
