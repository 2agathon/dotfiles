import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


WORK_ROOT = Path(r"D:\data\save_tmp\ptsg-work")
OUTPUT_ROOT = Path(r"D:\data\save_tmp\ptsg-output")
DEFAULT_RUN_DIR = WORK_ROOT / "run"

ALLOWED_HEADERS = {
    "namespace",
    "category_id",
    "category_name",
    "category_description",
    "type_id",
    "type_name",
    "Block",
    "Block id",
    "Block description",
    "tag名称",
    "Block role",
    "tag编码",
    "tag定义",
    "tag anchor binding",
    "触发模式",
    "正例",
    "反例",
    "必须",
    "块摘要构造和输出组装",
    "采集和转化规范",
    "缺项处理",
    "冲突处理",
    "情景",
    "情景id",
    "阶段",
    "阶段id",
    "动作",
    "动作id",
}

HEADER_ALIASES = {
    "namespce": "namespace",
    "Bolck role": "Block role",
}

BLOCK_START_FIELDS = {"Block id"}
MERGED_FILL_EXCLUDE = {"Block id", "tag编码", "tag名称", "Block role"}
ID_FIELDS = {
    "namespace",
    "category_id",
    "category_name",
    "category_description",
    "type_id",
    "type_name",
    "Block",
    "Block id",
    "Block description",
}
TAG_SIGNAL_FIELDS = {
    "tag编码",
    "tag定义",
    "tag anchor binding",
    "触发模式",
    "正例",
    "反例",
    "必须",
    "Block role",
}


def json_dump(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def json_load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_text(value):
    if value is None:
        return None
    if isinstance(value, str):
        value = value.replace("\r\n", "\n").replace("\r", "\n")
        value = re.sub(r"[ \t]+", " ", value).strip()
        return value or None
    return value


def detect_header_row(raw):
    best = None
    for sheet in raw["sheets"]:
        for row in sheet["rows"]:
            score = 0
            for cell in row["cells"]:
                value = normalize_text(cell["raw_value"])
                if value in ALLOWED_HEADERS or value in HEADER_ALIASES:
                    score += 1
            if best is None or score > best["score"]:
                best = {
                    "sheet": sheet["name"],
                    "row_index": row["row_index"],
                    "score": score,
                }
    return best


def merged_value_map(raw, sheet_name):
    sheet = next(item for item in raw["sheets"] if item["name"] == sheet_name)
    rows = {row["row_index"]: row for row in sheet["rows"]}
    result = {}
    for rng in sheet.get("merged_ranges", []):
        start, end = rng.split(":")
        start_col = re.match(r"[A-Z]+", start).group(0)
        start_row = int(re.search(r"\d+", start).group(0))
        end_col = re.match(r"[A-Z]+", end).group(0)
        end_row = int(re.search(r"\d+", end).group(0))
        start_idx = col_label_to_index(start_col)
        end_idx = col_label_to_index(end_col)
        top_row = rows.get(start_row)
        if not top_row:
            continue
        top_value = None
        for cell in top_row["cells"]:
            if cell["col_index"] == start_idx:
                top_value = normalize_text(cell["raw_value"])
                break
        if top_value is None:
            continue
        for row_index in range(start_row, end_row + 1):
            for col_index in range(start_idx, end_idx + 1):
                result[(row_index, col_index)] = {
                    "value": top_value,
                    "source_row": start_row,
                }
    return result


def col_label_to_index(label):
    idx = 0
    for char in label:
        idx = idx * 26 + (ord(char) - 64)
    return idx


def build_header_mapping(header_row):
    mapping = {}
    repairs = []
    for cell in header_row["cells"]:
        raw_value = normalize_text(cell["raw_value"])
        if raw_value is None:
            continue
        normalized = raw_value
        repair_type = None
        if raw_value in ALLOWED_HEADERS:
            repair_type = "exact_match"
        elif raw_value in HEADER_ALIASES:
            normalized = HEADER_ALIASES[raw_value]
            repair_type = "known_alias"
        else:
            trimmed = raw_value.strip()
            squeezed = re.sub(r"\s+", " ", trimmed)
            if squeezed in ALLOWED_HEADERS:
                normalized = squeezed
                repair_type = (
                    "trim_whitespace" if raw_value != trimmed else "normalize_spacing"
                )
            else:
                normalized = raw_value
                repair_type = "unrecognized_header"
        mapping[cell["col_label"]] = {
            "raw_header": raw_value,
            "normalized_header": normalized,
            "repair_type": repair_type,
        }
        if repair_type != "exact_match":
            repairs.append(
                {
                    "col_label": cell["col_label"],
                    "raw_header": raw_value,
                    "normalized_header": normalized,
                    "repair_type": repair_type,
                }
            )
    return mapping, repairs


def classify_row(normalized_fields, direct_fields, current_block):
    normalized_values = [
        value for value in normalized_fields.values() if value not in (None, "")
    ]
    if not normalized_values:
        return "empty", current_block
    direct_block_id = direct_fields.get("Block id")
    if direct_block_id:
        current_block = direct_block_id
        return "block_start", current_block
    tag_name = normalized_fields.get("tag名称")
    if tag_name and any(normalized_fields.get(field) for field in TAG_SIGNAL_FIELDS):
        return "tag_candidate", current_block
    if (not tag_name) and normalized_fields.get("Block role"):
        return "helper_candidate", current_block
    return "unknown", current_block


def make_canonical_id(
    prefix, raw_id=None, name=None, role=None, placeholder=False, used=None
):
    used = used if used is not None else set()
    legal_prefix = f"{prefix}_"
    source = normalize_text(raw_id)
    if source and source.upper().startswith(legal_prefix):
        candidate = source.upper()
    else:
        token_source = source if source else None
        token = normalize_token(token_source)
        if not token and not placeholder:
            token = normalize_token(name)
        if not token and not placeholder:
            token = normalize_token(role)
        if not token:
            token = "UNNAMED"
        if placeholder or not normalize_token(source):
            candidate = (
                f"{legal_prefix}PLACEHOLDER_{token}"
                if placeholder
                else f"{legal_prefix}{token}"
            )
        else:
            candidate = f"{legal_prefix}{token}"
    base = candidate
    counter = 2
    while candidate in used:
        candidate = f"{base}_DUP{counter}"
        counter += 1
    used.add(candidate)
    return candidate


def normalize_token(value):
    value = normalize_text(value)
    if not value:
        return ""
    parts = []
    for char in str(value):
        parts.append(char if re.match(r"[A-Za-z0-9]", char) else "_")
    token = "".join(parts)
    token = token.replace(".", "_")
    token = re.sub(r"_+", "_", token).strip("_")
    return token.upper()


def build_run_manifest(args):
    input_path = Path(args.input).resolve()
    run_dir = Path(args.run_dir).resolve()
    manifest = {
        "run_id": datetime.now(timezone.utc).strftime("run-%Y%m%dT%H%M%SZ"),
        "mode": args.mode,
        "inputs": [
            {
                "path": str(input_path),
                "name": input_path.name,
                "exists": input_path.exists(),
                "kind": "xlsx",
            }
        ],
        "has_page_types_data": False,
        "has_page_types_tree": False,
        "selected_types": [],
        "current_stage": 0,
        "run_dir": str(run_dir),
        "output_root": str(OUTPUT_ROOT),
    }
    json_dump(run_dir / "run-manifest.json", manifest)
    return run_dir / "run-manifest.json"


def parse_workbook(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    input_path = Path(manifest["inputs"][0]["path"])
    workbook = load_workbook(input_path, data_only=False, read_only=False)
    raw = {
        "workbook": {
            "path": str(input_path),
            "sheet_names": workbook.sheetnames,
            "sheet_order": workbook.sheetnames,
        },
        "sheets": [],
    }
    for ws in workbook.worksheets:
        sheet = {
            "name": ws.title,
            "max_row": ws.max_row,
            "max_column": ws.max_column,
            "merged_ranges": [str(rng) for rng in ws.merged_cells.ranges],
            "hidden_rows": [
                idx for idx, dim in ws.row_dimensions.items() if dim.hidden
            ],
            "rows": [],
        }
        for row in ws.iter_rows():
            cells = []
            has_value = False
            for cell in row:
                value = cell.value
                if value not in (None, ""):
                    has_value = True
                cells.append(
                    {
                        "col_index": cell.column,
                        "col_label": get_column_letter(cell.column),
                        "raw_value": value,
                    }
                )
            if not has_value:
                continue
            sheet["rows"].append({"row_index": row[0].row, "cells": cells})
        raw["sheets"].append(sheet)
    json_dump(run_dir / "workbook.raw.json", raw)
    manifest["current_stage"] = 1
    json_dump(run_dir / "run-manifest.json", manifest)
    return run_dir / "workbook.raw.json"


def normalize_workbook(args):
    run_dir = Path(args.run_dir).resolve()
    raw = json_load(run_dir / "workbook.raw.json")
    manifest = json_load(run_dir / "run-manifest.json")
    header_info = detect_header_row(raw)
    sheet = next(item for item in raw["sheets"] if item["name"] == header_info["sheet"])
    header_row = next(
        row for row in sheet["rows"] if row["row_index"] == header_info["row_index"]
    )
    header_mapping, header_repairs = build_header_mapping(header_row)
    merged_map = merged_value_map(raw, sheet["name"])

    normalized_rows = []
    fill_records = []
    current_block = None
    pre_header_rows = []
    for row in sheet["rows"]:
        if row["row_index"] < header_info["row_index"]:
            pre_header_rows.append(row["row_index"])
            continue
        if row["row_index"] == header_info["row_index"]:
            continue
        direct_fields = {}
        normalized_fields = {}
        field_sources = {}
        for cell in row["cells"]:
            header = header_mapping.get(cell["col_label"])
            if not header:
                continue
            normalized_header = header["normalized_header"]
            if normalized_header not in ALLOWED_HEADERS:
                continue
            direct_value = normalize_text(cell["raw_value"])
            value = direct_value
            source_row = row["row_index"]
            merged = merged_map.get((row["row_index"], cell["col_index"]))
            if (
                value is None
                and merged
                and normalized_header not in MERGED_FILL_EXCLUDE
            ):
                value = merged["value"]
                source_row = merged["source_row"]
                fill_records.append(
                    {
                        "row_index": row["row_index"],
                        "field": normalized_header,
                        "from_row": source_row,
                        "fill_type": "merged_inheritance",
                    }
                )
            normalized_fields[normalized_header] = value
            direct_fields[normalized_header] = direct_value
            field_sources[normalized_header] = source_row
        row_kind, current_block = classify_row(
            normalized_fields, direct_fields, current_block
        )
        normalized_rows.append(
            {
                "row_index": row["row_index"],
                "normalized_fields": normalized_fields,
                "direct_fields": direct_fields,
                "field_sources": field_sources,
                "row_kind": row_kind,
                "current_block_context": current_block,
            }
        )

    normalization_report = render_normalization_report(
        header_info,
        header_repairs,
        fill_records,
        normalized_rows,
        pre_header_rows,
    )
    normalized = {
        "source_sheet": sheet["name"],
        "header_row_index": header_info["row_index"],
        "header_detection": header_info,
        "header_mapping": header_mapping,
        "header_repairs": header_repairs,
        "pre_header_rows": pre_header_rows,
        "fill_records": fill_records,
        "rows": normalized_rows,
    }
    json_dump(run_dir / "workbook.normalized.json", normalized)
    (run_dir / "normalization-report.md").write_text(
        normalization_report, encoding="utf-8"
    )
    manifest["current_stage"] = 2
    json_dump(run_dir / "run-manifest.json", manifest)


def render_normalization_report(
    header_info, header_repairs, fill_records, normalized_rows, pre_header_rows
):
    row_kind_counts = {}
    for row in normalized_rows:
        row_kind_counts[row["row_kind"]] = row_kind_counts.get(row["row_kind"], 0) + 1
    lines = [
        "# normalization-report",
        "",
        "## 表头修复摘要",
        f"- 检测到表头行: {header_info['row_index']}",
        f"- 表头修复数: {len(header_repairs)}",
    ]
    for repair in header_repairs:
        lines.append(
            f"- {repair['col_label']}: `{repair['raw_header']}` -> `{repair['normalized_header']}` ({repair['repair_type']})"
        )
    lines.extend(
        [
            "",
            "## 继承填充摘要",
            f"- 继承填充数: {len(fill_records)}",
            "",
            "## 文本清洗摘要",
            "- 已统一换行并裁剪首尾空白。",
            "",
            "## 行分类摘要",
        ]
    )
    for key in sorted(row_kind_counts):
        lines.append(f"- {key}: {row_kind_counts[key]}")
    if pre_header_rows:
        lines.extend(
            [
                "",
                "## 预表头行",
                f"- 已保留于 raw parse，未纳入 normalized rows: {pre_header_rows}",
            ]
        )
    return "\n".join(lines) + "\n"


def resolve_identity(args):
    run_dir = Path(args.run_dir).resolve()
    normalized = json_load(run_dir / "workbook.normalized.json")
    manifest = json_load(run_dir / "run-manifest.json")
    used_ids = {"CATEGORY": set(), "TYPE": set(), "BLOCK": set(), "TAG": set()}
    namespace_values = []
    categories = {}
    types = {}
    blocks = {}
    tags = {}
    issues = {
        "empty_tag_code_rows": [],
        "placeholder_rows": [],
        "conflicts": [],
        "blocked": [],
    }
    explicit_tag_name_map = {}
    explicit_tag_code_map = {}
    for row in normalized["rows"]:
        fields = row["normalized_fields"]
        if fields.get("tag名称") and fields.get("tag编码"):
            tag_scope = fields.get("type_id") or fields.get("type_name") or "GLOBAL"
            raw_tag_id = normalize_text(fields.get("tag编码"))
            code_key = (tag_scope, raw_tag_id)
            if code_key not in explicit_tag_code_map:
                explicit_tag_code_map[code_key] = make_canonical_id(
                    "TAG",
                    raw_id=fields.get("tag编码"),
                    used=used_ids["TAG"],
                )
            explicit_tag_name_map[(tag_scope, normalize_text(fields["tag名称"]))] = (
                explicit_tag_code_map[code_key]
            )

    used_ids["TAG"].clear()
    recovered_tag_name_map = {}
    current_type_canonical = None
    current_block_canonical = None
    for row in normalized["rows"]:
        fields = row["normalized_fields"]
        if fields.get("namespace"):
            namespace_values.append(fields["namespace"])

        if fields.get("category_id") or fields.get("category_name"):
            category_key = (fields.get("category_id"), fields.get("category_name"))
            if category_key not in categories:
                categories[category_key] = {
                    "canonical_id": make_canonical_id(
                        "CATEGORY",
                        raw_id=fields.get("category_id"),
                        name=fields.get("category_name"),
                        used=used_ids["CATEGORY"],
                    ),
                    "raw_id": fields.get("category_id"),
                    "name": fields.get("category_name"),
                    "description": fields.get("category_description"),
                    "source_rows": [row["row_index"]],
                }
            else:
                categories[category_key]["source_rows"].append(row["row_index"])

        if fields.get("type_id") or fields.get("type_name"):
            type_key = (fields.get("type_id"), fields.get("type_name"))
            if type_key not in types:
                canonical = make_canonical_id(
                    "TYPE",
                    raw_id=fields.get("type_id"),
                    name=fields.get("type_name"),
                    used=used_ids["TYPE"],
                )
                types[type_key] = {
                    "canonical_id": canonical,
                    "raw_id": fields.get("type_id"),
                    "name": fields.get("type_name"),
                    "category_canonical_id": categories[
                        (fields.get("category_id"), fields.get("category_name"))
                    ]["canonical_id"],
                    "source_rows": [row["row_index"]],
                }
            else:
                types[type_key]["source_rows"].append(row["row_index"])
            current_type_canonical = types[type_key]["canonical_id"]

        if row["row_kind"] == "block_start":
            block_name = fields.get("Block")
            block_raw_id = fields.get("Block id")
            if not block_raw_id:
                issues["blocked"].append(
                    {
                        "row_index": row["row_index"],
                        "reason": "block_start_without_block_id",
                    }
                )
                continue
            current_block_canonical = make_canonical_id(
                "BLOCK",
                raw_id=block_raw_id,
                name=block_name,
                used=used_ids["BLOCK"],
            )
            blocks[current_block_canonical] = {
                "canonical_id": current_block_canonical,
                "raw_id": block_raw_id,
                "name": block_name,
                "description": fields.get("Block description"),
                "type_canonical_id": current_type_canonical,
                "source_rows": [row["row_index"]],
                "tag_refs": [],
            }

        if row["row_kind"] not in {"tag_candidate", "helper_candidate"}:
            continue

        tag_name = fields.get("tag名称")
        tag_role = fields.get("Block role")
        tag_raw_id = fields.get("tag编码")
        tag_scope = fields.get("type_id") or fields.get("type_name") or "GLOBAL"
        if row["row_kind"] == "helper_candidate":
            tag_key = f"helper::{row['row_index']}"
            tags[tag_key] = {
                "canonical_id": None,
                "name": tag_name,
                "identity_state": "helper_only",
                "source_rows": [row["row_index"]],
                "type_canonical_id": current_type_canonical,
                "block_canonical_id": current_block_canonical,
                "role": tag_role,
            }
            continue

        if not current_block_canonical or not current_type_canonical:
            issues["blocked"].append(
                {
                    "row_index": row["row_index"],
                    "reason": "tag_without_stable_block_or_type",
                }
            )
            continue

        identity_state = "resolved_explicit"
        placeholder_reason = None
        if tag_raw_id:
            code_key = (tag_scope, normalize_text(tag_raw_id))
            canonical_tag_id = explicit_tag_code_map.get(code_key)
            if not canonical_tag_id:
                canonical_tag_id = make_canonical_id(
                    "TAG", raw_id=tag_raw_id, used=used_ids["TAG"]
                )
                explicit_tag_code_map[code_key] = canonical_tag_id
            used_ids["TAG"].add(canonical_tag_id)
        else:
            issues["empty_tag_code_rows"].append(
                {
                    "row_index": row["row_index"],
                    "tag_name": tag_name,
                    "block_id": current_block_canonical,
                }
            )
            name_key = (tag_scope, normalize_text(tag_name))
            inherited = explicit_tag_name_map.get(name_key)
            if inherited:
                canonical_tag_id = inherited
                used_ids["TAG"].add(canonical_tag_id)
            else:
                recovered = recovered_tag_name_map.get(name_key)
                if recovered:
                    canonical_tag_id = recovered
                    used_ids["TAG"].add(canonical_tag_id)
                    identity_state = "resolved_recovered"
                else:
                    recovered_token = normalize_token(tag_name) or normalize_token(
                        tag_role
                    )
                    if recovered_token:
                        canonical_tag_id = make_canonical_id(
                            "TAG",
                            raw_id=tag_name,
                            name=tag_name,
                            role=tag_role,
                            used=used_ids["TAG"],
                        )
                        recovered_tag_name_map[name_key] = canonical_tag_id
                        identity_state = "resolved_recovered"
                    else:
                        canonical_tag_id = make_canonical_id(
                            "TAG",
                            name=tag_name,
                            role=tag_role,
                            placeholder=True,
                            used=used_ids["TAG"],
                        )
                        identity_state = "resolved_placeholder"
                        placeholder_reason = "missing_tag_code_and_unstable_name_token"

        tag_key = canonical_tag_id
        if tag_key not in tags:
            tags[tag_key] = {
                "canonical_id": canonical_tag_id,
                "name": tag_name,
                "identity_state": identity_state,
                "source_rows": [row["row_index"]],
                "type_canonical_id": current_type_canonical,
                "block_canonical_id": current_block_canonical,
                "raw_id": tag_raw_id,
                "role": tag_role,
                "placeholder_reason": placeholder_reason,
                "tag_definition": fields.get("tag定义"),
                "anchor_binding_source": fields.get("tag anchor binding"),
                "trigger_mode": fields.get("触发模式"),
                "positive_examples": fields.get("正例"),
                "negative_examples": fields.get("反例"),
                "required_text": fields.get("必须"),
            }
        else:
            tags[tag_key]["source_rows"].append(row["row_index"])

        ref = {
            "tag_id": canonical_tag_id,
            "role": tag_role,
            "source_row": row["row_index"],
        }
        if ref not in blocks[current_block_canonical]["tag_refs"]:
            blocks[current_block_canonical]["tag_refs"].append(ref)
        if identity_state == "resolved_placeholder":
            issues["placeholder_rows"].append(
                {
                    "row_index": row["row_index"],
                    "tag_name": tag_name,
                    "placeholder_id": canonical_tag_id,
                    "reason": placeholder_reason,
                }
            )

    namespace = next((value for value in namespace_values if value), None)
    blocked_reasons = list(issues["blocked"])
    if not namespace:
        blocked_reasons.append({"row_index": None, "reason": "missing_namespace"})
    for tag in tags.values():
        if tag.get("identity_state") == "helper_only":
            continue
        if not tag.get("canonical_id"):
            blocked_reasons.append(
                {"row_index": tag["source_rows"][0], "reason": "empty_tag_canonical_id"}
            )

    identity = {
        "namespace": namespace,
        "categories": list(categories.values()),
        "types": list(types.values()),
        "blocks": list(blocks.values()),
        "tags": [tag for tag in tags.values()],
        "empty_tag_code_rows": issues["empty_tag_code_rows"],
        "placeholder_rows": issues["placeholder_rows"],
        "issues": {
            "conflicts": issues["conflicts"],
            "blocked": blocked_reasons,
        },
        "status": "blocked" if blocked_reasons else "ready_for_type_selection",
    }
    json_dump(run_dir / "identity-map.json", identity)
    (run_dir / "identity-issues.md").write_text(
        render_identity_issues(identity), encoding="utf-8"
    )
    manifest["current_stage"] = 3
    json_dump(run_dir / "run-manifest.json", manifest)


def render_identity_issues(identity):
    lines = ["# identity-issues", "", "## 空 tag编码 行处理记录"]
    if identity["empty_tag_code_rows"]:
        for item in identity["empty_tag_code_rows"]:
            lines.append(
                f"- row {item['row_index']}: `{item['tag_name']}` in `{item['block_id']}` entered recovery flow"
            )
    else:
        lines.append("- 无")
    lines.extend(["", "## 占位符生成记录"])
    if identity["placeholder_rows"]:
        for item in identity["placeholder_rows"]:
            lines.append(
                f"- row {item['row_index']}: `{item['tag_name']}` -> `{item['placeholder_id']}` ({item['reason']})"
            )
    else:
        lines.append("- 无")
    lines.extend(["", "## 身份冲突"])
    if identity["issues"]["conflicts"]:
        for item in identity["issues"]["conflicts"]:
            lines.append(f"- {json.dumps(item, ensure_ascii=False)}")
    else:
        lines.append("- 无")
    lines.extend(["", "## blocked 对象"])
    if identity["issues"]["blocked"]:
        for item in identity["issues"]["blocked"]:
            lines.append(f"- {json.dumps(item, ensure_ascii=False)}")
    else:
        lines.append("- 无")
    return "\n".join(lines) + "\n"


def enumerate_types(args):
    run_dir = Path(args.run_dir).resolve()
    identity = json_load(run_dir / "identity-map.json")
    types = [
        {
            "canonical_id": item["canonical_id"],
            "raw_id": item["raw_id"],
            "name": item["name"],
        }
        for item in identity["types"]
    ]
    output = {"status": identity["status"], "types": types}
    print(json.dumps(output, ensure_ascii=False, indent=2))


def resolve_selected_type(identity, selected_type):
    for item in identity["types"]:
        if item["canonical_id"] == selected_type or item["raw_id"] == selected_type:
            return item
    raise ValueError(f"unknown selected type: {selected_type}")


def select_type(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    identity = json_load(run_dir / "identity-map.json")
    selected = resolve_selected_type(identity, args.selected_type)
    manifest["selected_types"] = [selected["canonical_id"]]
    manifest["selected_type_raw_ids"] = [selected["raw_id"]]
    manifest["current_stage"] = 4
    json_dump(run_dir / "run-manifest.json", manifest)


def check_existence(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    result = {
        "has_page_types_data": manifest.get("has_page_types_data", False),
        "has_page_types_tree": manifest.get("has_page_types_tree", False),
        "action": "new"
        if not manifest.get("has_page_types_data")
        and not manifest.get("has_page_types_tree")
        else "merge_required",
        "conflicts": [],
    }
    json_dump(run_dir / "existence-check.json", result)
    manifest["current_stage"] = 5
    json_dump(run_dir / "run-manifest.json", manifest)


def build_context(run_dir):
    identity = json_load(run_dir / "identity-map.json")
    normalized = json_load(run_dir / "workbook.normalized.json")
    manifest = json_load(run_dir / "run-manifest.json")
    selected_type_id = manifest["selected_types"][0]
    selected_type = next(
        item for item in identity["types"] if item["canonical_id"] == selected_type_id
    )
    selected_category = next(
        item
        for item in identity["categories"]
        if item["canonical_id"] == selected_type["category_canonical_id"]
    )
    row_map = {row["row_index"]: row for row in normalized["rows"]}
    blocks = [
        block
        for block in identity["blocks"]
        if block["type_canonical_id"] == selected_type_id
    ]
    blocks.sort(key=lambda item: item["source_rows"][0])
    tag_ids = []
    for block in blocks:
        for ref in block["tag_refs"]:
            if ref["tag_id"] not in tag_ids:
                tag_ids.append(ref["tag_id"])
    tags = [
        tag
        for tag in identity["tags"]
        if tag.get("canonical_id") in tag_ids
        and tag.get("identity_state")
        in {"resolved_explicit", "resolved_recovered", "resolved_placeholder"}
    ]
    tags.sort(key=lambda item: item["source_rows"][0])
    block_rows = {}
    for block in blocks:
        row = row_map[block["source_rows"][0]]
        block_rows[block["canonical_id"]] = row["normalized_fields"]
    return {
        "manifest": manifest,
        "identity": identity,
        "normalized": normalized,
        "selected_type": selected_type,
        "selected_category": selected_category,
        "blocks": blocks,
        "tags": tags,
        "block_rows": block_rows,
        "tag_ids": tag_ids,
        "row_map": row_map,
    }


def build_taxonomy_doc(context):
    selected_type = context["selected_type"]
    selected_category = context["selected_category"]
    description = f"Generated taxonomy for {selected_type['raw_id']} from {context['manifest']['inputs'][0]['name']}."
    taxonomy = {
        "version": "1.0.0",
        "description": description,
        "last_updated": datetime.now().date().isoformat(),
        "categories": [
            {
                "id": selected_category["canonical_id"],
                "name": selected_category["name"],
                "description": selected_category["description"],
                "types": [
                    {
                        "id": selected_type["canonical_id"],
                        "name": selected_type["name"],
                        "description": f"Generated from workbook type {selected_type['raw_id']}.",
                    }
                ],
            }
        ],
    }
    return taxonomy


def build_skeleton(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    context = build_context(run_dir)
    skeleton_dir = run_dir / "skeleton"
    skeleton_dir.mkdir(parents=True, exist_ok=True)
    taxonomy = build_taxonomy_doc(context)
    json_dump(skeleton_dir / "page-types.data.json", taxonomy)
    json_dump(skeleton_dir / "page-types.tree.json", taxonomy)

    tag_map = {tag["canonical_id"]: tag for tag in context["tags"]}
    semantic = {
        "version": "1.1.0",
        "page_type": {
            "id": context["selected_type"]["canonical_id"],
            "name": context["selected_type"]["name"],
        },
        "block_types": [],
        "tags": [],
    }
    for block in context["blocks"]:
        semantic["block_types"].append(
            {
                "id": block["canonical_id"],
                "name": block["name"],
                "tags": [
                    {
                        k: v
                        for k, v in {
                            "tag_id": ref["tag_id"],
                            "role": ref.get("role"),
                        }.items()
                        if v is not None
                    }
                    for ref in block["tag_refs"]
                    if ref["tag_id"] in tag_map
                ],
            }
        )
    for tag in context["tags"]:
        semantic["tags"].append(
            {
                "id": tag["canonical_id"],
                "name": tag["name"],
                "value_hint": "TODO_STAGE_7_VALUE_HINT",
            }
        )
    json_dump(skeleton_dir / "page-semantic-spec.json", semantic)
    for name, title in build_empty_hint_templates(
        context["selected_type"]["name"]
    ).items():
        (skeleton_dir / name).write_text(title, encoding="utf-8")
    manifest["current_stage"] = 6
    json_dump(run_dir / "run-manifest.json", manifest)


def build_empty_hint_templates(type_name):
    return {
        "tagging-hint.md": f"# {type_name} · 段打标处理指导\n\n<!-- TODO: 当前设计稿未提供专门的段打标补充规则 -->\n",
        "assembly-hint.md": f"# {type_name} · 块组装处理指导\n\n<!-- TODO: 当前设计稿未提供专门的块组装规则 -->\n",
        "block-summary-hint.md": f"# {type_name} · 块摘要生成指导\n\n<!-- TODO: 当前设计稿未提供专门的块摘要规则 -->\n",
        "page-summary-hint.md": f"# {type_name} · 页摘要生成指导\n\n<!-- TODO: 当前设计稿未提供专门的页摘要规则 -->\n",
        "continuation-hint.md": f"# {type_name} · 续写判定提示\n\n<!-- TODO: 当前设计稿未提供专门的续写规则 -->\n",
    }


def clean_rule_text(text):
    text = normalize_text(text)
    if not text:
        return None
    return text.rstrip("。；;，,")


def first_clause(text):
    text = normalize_text(text)
    if not text:
        return None
    text = text.replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    parts = re.split(r"[。；;]", text)
    for part in parts:
        part = part.strip(" ，,")
        if part:
            return part
    return text


def is_time_like(tag):
    blob = " ".join(
        str(tag.get(key) or "") for key in ["name", "tag_definition", "role", "raw_id"]
    )
    return any(
        token in blob
        for token in [
            "时间",
            "日期",
            "时长",
            "持续",
            "report_time",
            "record_time",
            "duration",
        ]
    )


def generate_block_description(block, block_fields, block_tags):
    raw = clean_rule_text(block.get("description")) or clean_rule_text(
        block.get("name")
    )
    strategy_terms = ["优先", "缺项", "冲突", "组装", "拼接", "拆分", "字数", "抑制"]
    sentences = []
    if raw:
        for sentence in re.split(r"[。；;]", raw):
            sentence = sentence.strip(" ，,")
            if sentence and not any(term in sentence for term in strategy_terms):
                sentences.append(sentence)
    if sentences:
        base = "。".join(sentences).strip()
        return base if base.endswith("。") else base + "。"
    tag_names = [tag["name"] for tag in block_tags[:4]]
    dimension = "、".join(tag_names) if tag_names else "相关标签"
    return f"该块围绕{block['name']}所表达的对象展开，覆盖{dimension}等语义维度。"


def generate_value_hint(tag):
    definition = (
        first_clause(tag.get("tag_definition")) or f"{tag['name']}对应的稳定语义值"
    )
    trigger = first_clause(tag.get("trigger_mode")) or first_clause(
        tag.get("positive_examples")
    )
    negative = first_clause(tag.get("negative_examples"))
    must = normalize_text(tag.get("required_text"))
    s1 = f"抓取{definition}。"
    s2 = (
        f"优先识别与该语义直接对应的表达，重点关注{trigger}。"
        if trigger
        else "优先识别与该语义直接对应的稳定表述。"
    )
    if negative:
        if any(token in negative for token in ["未", "无", "不详", "无法", "缺"]):
            s3 = "原文未提供可稳定确认的值时，不打本标签。"
        else:
            s3 = f"不要把{negative}这类与当前语义边界不一致的表述记为本标签。"
    else:
        s3 = "不要把仅起补充说明作用、不能独立成立的表述记为本标签。"
    if is_time_like(tag):
        s4 = "输出单值，时间类内容按可稳定规范化的日期、时点或时长表达写入。"
    else:
        s4 = "输出单值，保留与当前语义直接对应的核心值。"
    if must == "是":
        s4 += "原文无明确表述时不打本标签。"
    else:
        s4 += "原文无稳定值时可缺省。"
    return " ".join([s1, s2, s3, s4])


def generate_context_hint(tag, block):
    blob = " ".join(
        str(tag.get(key) or "") for key in ["name", "tag_definition", "role"]
    )
    if "入院日期" in blob:
        return "应补足这是本次入院对应的时间来源。"
    if "报告时间" in blob:
        return "应补足这是本次报告生成或出具的时间。"
    if "记录时间" in blob:
        return "应补足这是当前材料块的记录形成时间。"
    if any(token in blob for token in ["起病", "发病"]):
        return "应补足这是症状或事件开始发生的时间。"
    if any(token in blob for token in ["既往", "当前"]):
        return "应补足这是既往情况还是当前就诊情况。"
    return None


def parse_anchor_binding(text):
    raw = normalize_text(text)
    if not raw:
        return None, [], []
    fixes = []
    problems = []
    mode = None
    mode_match = re.search(r"page_window\.mode\s*:\s*\{?\s*\"?([a-z_]+)\"?\s*\}?", raw)
    if mode_match:
        mode = mode_match.group(1)
        if mode == "with_type_run":
            fixes.append(
                {"repair_type": "known_alias", "from": mode, "to": "within_type_run"}
            )
            mode = "within_type_run"
    else:
        mode = "within_type_run"
        fixes.append(
            {"repair_type": "default_value", "field": "page_window.mode", "to": mode}
        )
    direction_match = re.search(r"direction\s*:\s*\"?([a-z_]+)\"?", raw)
    direction = direction_match.group(1) if direction_match else None
    if not direction:
        problems.append("missing_direction")
    required_match = re.search(r"required\s*:\s*(true|false)", raw, re.IGNORECASE)
    required = required_match.group(1).lower() == "true" if required_match else True
    if not required_match:
        fixes.append({"repair_type": "default_value", "field": "required", "to": True})
    self_resolution_match = re.search(r"self_resolution\s*:\s*\"?([a-z_]+)\"?", raw)
    self_resolution = (
        self_resolution_match.group(1) if self_resolution_match else "direction_only"
    )
    if not self_resolution_match:
        fixes.append(
            {
                "repair_type": "default_value",
                "field": "self_resolution",
                "to": self_resolution,
            }
        )
    target_tag_ids = re.findall(r"TAG_[A-Z0-9_]+", raw)
    if not target_tag_ids:
        problems.append("missing_target_tag_ids")
    binding = {
        "target_tag_ids": target_tag_ids,
        "page_window": {"mode": mode},
        "direction": direction,
        "required": required,
        "self_resolution": self_resolution,
    }
    if mode == "bounded":
        prev_match = re.search(r"prev\s*:\s*(\d+)", raw)
        next_match = re.search(r"next\s*:\s*(\d+)", raw)
        if prev_match and next_match:
            binding["page_window"]["prev"] = int(prev_match.group(1))
            binding["page_window"]["next"] = int(next_match.group(1))
        else:
            problems.append("bounded_missing_prev_next")
    if problems:
        return None, fixes, problems
    return binding, fixes, problems


def build_tagging_hint(context):
    lines = [f"# {context['selected_type']['name']} · 段打标处理指导", ""]
    boundary_rules = []
    normalization_rules = []
    for tag in context["tags"]:
        negative = first_clause(tag.get("negative_examples"))
        if negative:
            boundary_rules.append(
                f"- {tag['name']}: 不把{negative}这类与当前标签边界不一致的表述误记为本标签。"
            )
    for block in context["blocks"]:
        fields = context["block_rows"][block["canonical_id"]]
        collect = first_clause(fields.get("采集和转化规范"))
        if collect:
            normalization_rules.append(f"- {block['name']}: {collect}。")
    if not boundary_rules and not normalization_rules:
        return build_empty_hint_templates(context["selected_type"]["name"])[
            "tagging-hint.md"
        ]
    if boundary_rules:
        lines.extend(["## 标签边界", *dedupe_lines(boundary_rules)])
    if normalization_rules:
        lines.extend(["", "## 单段规范", *dedupe_lines(normalization_rules[:8])])
    return "\n".join(lines) + "\n"


def build_assembly_hint(context):
    sections = {"采集与规范化": [], "缺项处理": [], "冲突处理": []}
    for block in context["blocks"]:
        fields = context["block_rows"][block["canonical_id"]]
        if fields.get("采集和转化规范"):
            sections["采集与规范化"].append(
                f"- {block['name']}: {clean_rule_text(fields['采集和转化规范'])}。"
            )
        if fields.get("缺项处理"):
            sections["缺项处理"].append(
                f"- {block['name']}: {clean_rule_text(fields['缺项处理'])}。"
            )
        if fields.get("冲突处理"):
            sections["冲突处理"].append(
                f"- {block['name']}: {clean_rule_text(fields['冲突处理'])}。"
            )
    if not any(sections.values()):
        return build_empty_hint_templates(context["selected_type"]["name"])[
            "assembly-hint.md"
        ]
    lines = [f"# {context['selected_type']['name']} · 块组装处理指导", ""]
    for title in ["采集与规范化", "缺项处理", "冲突处理"]:
        if sections[title]:
            lines.extend([f"## {title}", *dedupe_lines(sections[title]), ""])
    return "\n".join(lines).rstrip() + "\n"


def build_block_summary_hint(context):
    main_rules = []
    supplemental = []
    for block in context["blocks"]:
        fields = context["block_rows"][block["canonical_id"]]
        if fields.get("块摘要构造和输出组装"):
            main_rules.append(
                f"- {block['name']}: {clean_rule_text(fields['块摘要构造和输出组装'])}。"
            )
        for key in ["采集和转化规范", "缺项处理", "冲突处理"]:
            if fields.get(key):
                supplemental.append(
                    f"- {block['name']} / {key}: {clean_rule_text(fields[key])}。"
                )
    if not main_rules and not supplemental:
        return build_empty_hint_templates(context["selected_type"]["name"])[
            "block-summary-hint.md"
        ]
    lines = [f"# {context['selected_type']['name']} · 块摘要生成指导", ""]
    if main_rules:
        lines.extend(["## 摘要重点", *dedupe_lines(main_rules)])
    if supplemental:
        lines.extend(["", "## 补充约束", *dedupe_lines(supplemental[:12])])
    return "\n".join(lines) + "\n"


def dedupe_lines(lines):
    seen = set()
    result = []
    for line in lines:
        if line not in seen:
            seen.add(line)
            result.append(line)
    return result


def build_semantic_draft(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    context = build_context(run_dir)
    skeleton_dir = run_dir / "skeleton"
    draft_dir = run_dir / "semantic-draft"
    draft_dir.mkdir(parents=True, exist_ok=True)
    page_types_data = json_load(skeleton_dir / "page-types.data.json")
    page_types_tree = json_load(skeleton_dir / "page-types.tree.json")
    semantic = json_load(skeleton_dir / "page-semantic-spec.json")

    tag_lookup = {tag["canonical_id"]: tag for tag in context["tags"]}
    notes = {
        "anchor_binding_repairs": [],
        "anchor_binding_problems": [],
        "auto_decisions": [],
    }
    for block in semantic["block_types"]:
        source_block = next(
            item for item in context["blocks"] if item["canonical_id"] == block["id"]
        )
        block_tags = [
            tag_lookup[ref["tag_id"]]
            for ref in source_block["tag_refs"]
            if ref["tag_id"] in tag_lookup
        ]
        block["description"] = generate_block_description(
            source_block, context["block_rows"][block["id"]], block_tags
        )
    for tag in semantic["tags"]:
        source_tag = tag_lookup[tag["id"]]
        source_block = next(
            block
            for block in context["blocks"]
            if block["canonical_id"] == source_tag["block_canonical_id"]
        )
        tag["value_hint"] = generate_value_hint(source_tag)
        context_hint = generate_context_hint(source_tag, source_block)
        if context_hint:
            tag["context_hint"] = context_hint
        anchor_binding, fixes, problems = parse_anchor_binding(
            source_tag.get("anchor_binding_source")
        )
        if fixes:
            notes["anchor_binding_repairs"].append(
                {"tag_id": tag["id"], "fixes": fixes}
            )
        if problems:
            notes["anchor_binding_problems"].append(
                {"tag_id": tag["id"], "problems": problems}
            )
        if anchor_binding:
            tag["anchor_binding"] = anchor_binding
        if source_tag.get("identity_state") == "resolved_recovered":
            notes["auto_decisions"].append(
                f"{tag['id']} recovered from empty tag code using stable name or role token."
            )
    json_dump(draft_dir / "page-types.data.json", page_types_data)
    json_dump(draft_dir / "page-types.tree.json", page_types_tree)
    json_dump(draft_dir / "page-semantic-spec.json", semantic)
    (draft_dir / "tagging-hint.md").write_text(
        build_tagging_hint(context), encoding="utf-8"
    )
    (draft_dir / "assembly-hint.md").write_text(
        build_assembly_hint(context), encoding="utf-8"
    )
    (draft_dir / "block-summary-hint.md").write_text(
        build_block_summary_hint(context), encoding="utf-8"
    )
    empty_templates = build_empty_hint_templates(context["selected_type"]["name"])
    (draft_dir / "page-summary-hint.md").write_text(
        empty_templates["page-summary-hint.md"], encoding="utf-8"
    )
    (draft_dir / "continuation-hint.md").write_text(
        empty_templates["continuation-hint.md"], encoding="utf-8"
    )
    json_dump(draft_dir / "semantic-notes.json", notes)
    manifest["current_stage"] = 7
    json_dump(run_dir / "run-manifest.json", manifest)


def validate_schema(instance, schema_path):
    try:
        import jsonschema
    except ImportError:
        if schema_path.name == "page-types.schema.json":
            return manual_validate_page_types(instance)
        if schema_path.name == "page-semantic.schema.json":
            return manual_validate_page_semantic(instance)
        return [f"unsupported schema validator for {schema_path.name}"]
    schema = json_load(schema_path)
    validator = jsonschema.Draft202012Validator(schema)
    return [
        f"{error.json_path or '$'}: {error.message}"
        for error in validator.iter_errors(instance)
    ]


def manual_validate_page_types(instance):
    errors = []
    if not isinstance(instance, dict):
        return ["$: must be object"]
    required = {"version", "description", "last_updated", "categories"}
    missing = required - set(instance.keys())
    if missing:
        errors.append(f"$: missing required keys {sorted(missing)}")
    if not re.match(
        r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$",
        str(instance.get("version", "")),
    ):
        errors.append("$.version: invalid semver")
    if not isinstance(instance.get("description"), str) or not instance.get(
        "description"
    ):
        errors.append("$.description: must be non-empty string")
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(instance.get("last_updated", ""))):
        errors.append("$.last_updated: must be ISO date")
    categories = instance.get("categories")
    if not isinstance(categories, list) or not categories:
        errors.append("$.categories: must be non-empty array")
        return errors
    for idx, category in enumerate(categories):
        if not isinstance(category, dict):
            errors.append(f"$.categories[{idx}]: must be object")
            continue
        for key in ["id", "name", "description", "types"]:
            if key not in category:
                errors.append(f"$.categories[{idx}]: missing `{key}`")
        if not re.match(r"^[A-Z][A-Z0-9_]*$", str(category.get("id", ""))):
            errors.append(f"$.categories[{idx}].id: invalid pattern")
        if not isinstance(category.get("name"), str) or not category.get("name"):
            errors.append(f"$.categories[{idx}].name: must be non-empty string")
        if not isinstance(category.get("description"), str) or not category.get(
            "description"
        ):
            errors.append(f"$.categories[{idx}].description: must be non-empty string")
        types = category.get("types")
        if not isinstance(types, list) or not types:
            errors.append(f"$.categories[{idx}].types: must be non-empty array")
            continue
        for type_idx, type_item in enumerate(types):
            if not re.match(r"^[A-Z][A-Z0-9_]*$", str(type_item.get("id", ""))):
                errors.append(
                    f"$.categories[{idx}].types[{type_idx}].id: invalid pattern"
                )
            if not isinstance(type_item.get("name"), str) or not type_item.get("name"):
                errors.append(
                    f"$.categories[{idx}].types[{type_idx}].name: must be non-empty string"
                )
    return errors


def manual_validate_page_semantic(instance):
    errors = []
    if not isinstance(instance, dict):
        return ["$: must be object"]
    for key in ["version", "page_type", "block_types", "tags"]:
        if key not in instance:
            errors.append(f"$: missing `{key}`")
    page_type = instance.get("page_type", {})
    if not re.match(r"^TYPE_[A-Z0-9_]+$", str(page_type.get("id", ""))):
        errors.append("$.page_type.id: invalid pattern")
    if not isinstance(page_type.get("name"), str) or not page_type.get("name"):
        errors.append("$.page_type.name: must be non-empty string")
    blocks = instance.get("block_types")
    if not isinstance(blocks, list) or not blocks:
        errors.append("$.block_types: must be non-empty array")
    else:
        for idx, block in enumerate(blocks):
            if not re.match(r"^BLOCK_[A-Z0-9_]+$", str(block.get("id", ""))):
                errors.append(f"$.block_types[{idx}].id: invalid pattern")
            if not isinstance(block.get("name"), str) or not block.get("name"):
                errors.append(f"$.block_types[{idx}].name: must be non-empty string")
            tags = block.get("tags")
            if not isinstance(tags, list):
                errors.append(f"$.block_types[{idx}].tags: must be array")
                continue
            for ref_idx, ref in enumerate(tags):
                if not re.match(r"^TAG_[A-Z0-9_]+$", str(ref.get("tag_id", ""))):
                    errors.append(
                        f"$.block_types[{idx}].tags[{ref_idx}].tag_id: invalid pattern"
                    )
    tags = instance.get("tags")
    if not isinstance(tags, list):
        errors.append("$.tags: must be array")
    else:
        for idx, tag in enumerate(tags):
            if not re.match(r"^TAG_[A-Z0-9_]+$", str(tag.get("id", ""))):
                errors.append(f"$.tags[{idx}].id: invalid pattern")
            if not isinstance(tag.get("name"), str) or not tag.get("name"):
                errors.append(f"$.tags[{idx}].name: must be non-empty string")
            if not isinstance(tag.get("value_hint"), str) or not tag.get("value_hint"):
                errors.append(f"$.tags[{idx}].value_hint: must be non-empty string")
            anchor = tag.get("anchor_binding")
            if anchor is not None:
                if not isinstance(anchor.get("target_tag_ids"), list) or not anchor.get(
                    "target_tag_ids"
                ):
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.target_tag_ids: must be non-empty array"
                    )
                elif any(
                    not re.match(r"^TAG_[A-Z0-9_]+$", str(item))
                    for item in anchor.get("target_tag_ids", [])
                ):
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.target_tag_ids: invalid tag id pattern"
                    )
                if anchor.get("page_window", {}).get("mode") not in {
                    "within_type_run",
                    "bounded",
                }:
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.page_window.mode: invalid value"
                    )
                if anchor.get("direction") not in {
                    "before",
                    "after",
                    "same_segment",
                    "nearby",
                }:
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.direction: invalid value"
                    )
                if not isinstance(anchor.get("required"), bool):
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.required: must be boolean"
                    )
                if anchor.get("self_resolution") not in {
                    "self_only",
                    "self_first",
                    "direction_first",
                    "direction_only",
                }:
                    errors.append(
                        f"$.tags[{idx}].anchor_binding.self_resolution: invalid value"
                    )
                if anchor.get("page_window", {}).get("mode") == "bounded":
                    if "prev" not in anchor.get(
                        "page_window", {}
                    ) or "next" not in anchor.get("page_window", {}):
                        errors.append(
                            f"$.tags[{idx}].anchor_binding.page_window: bounded mode requires prev and next"
                        )
    return errors


def validate_outputs(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    context = build_context(run_dir)
    draft_dir = run_dir / "semantic-draft"
    notes = json_load(draft_dir / "semantic-notes.json")
    page_types_data = json_load(draft_dir / "page-types.data.json")
    page_types_tree = json_load(draft_dir / "page-types.tree.json")
    semantic = json_load(draft_dir / "page-semantic-spec.json")

    blocking = []
    warnings = []
    passed = []

    page_types_schema = Path(
        r"D:\exp.space\2agathon\idea-foundry\dotfiles\skills\page-type-spec-generator\schema\page-types.schema.json"
    )
    page_semantic_schema = Path(
        r"D:\exp.space\2agathon\idea-foundry\dotfiles\skills\page-type-spec-generator\schema\page-semantic.schema.json"
    )
    for name, instance, schema_path in [
        ("page-types.data.json", page_types_data, page_types_schema),
        ("page-types.tree.json", page_types_tree, page_types_schema),
        ("page-semantic-spec.json", semantic, page_semantic_schema),
    ]:
        errors = validate_schema(instance, schema_path)
        if errors:
            blocking.append({"gate": "schema", "file": name, "errors": errors})
        else:
            passed.append({"gate": "schema", "file": name})

    required_ids = [semantic["page_type"]["id"]]
    required_ids.extend(block["id"] for block in semantic["block_types"])
    required_ids.extend(tag["id"] for tag in semantic["tags"])
    required_ids.extend(
        ref["tag_id"] for block in semantic["block_types"] for ref in block["tags"]
    )
    required_ids.extend(cat["id"] for cat in page_types_data["categories"])
    required_ids.extend(
        tp["id"] for cat in page_types_data["categories"] for tp in cat["types"]
    )
    if any(not item for item in required_ids):
        blocking.append(
            {"gate": "required_id", "message": "empty required id detected"}
        )
    else:
        passed.append({"gate": "required_id"})

    identity_blocked = context["identity"]["issues"]["blocked"]
    if identity_blocked:
        blocking.append({"gate": "identity_blocked", "items": identity_blocked})
    else:
        passed.append({"gate": "identity_blocked"})

    selected_block_ids = {block["canonical_id"] for block in context["blocks"]}
    selected_tag_ids = {tag["canonical_id"] for tag in context["tags"]}
    if any(block["id"] not in selected_block_ids for block in semantic["block_types"]):
        blocking.append(
            {
                "gate": "type_pollution",
                "message": "block type outside selected type detected",
            }
        )
    elif any(tag["id"] not in selected_tag_ids for tag in semantic["tags"]):
        blocking.append(
            {"gate": "type_pollution", "message": "tag outside selected type detected"}
        )
    else:
        passed.append({"gate": "type_pollution"})

    semantic_tag_ids = {tag["id"] for tag in semantic["tags"]}
    missing_refs = [
        ref["tag_id"]
        for block in semantic["block_types"]
        for ref in block["tags"]
        if ref["tag_id"] not in semantic_tag_ids
    ]
    if missing_refs:
        blocking.append({"gate": "reference_closure", "missing_tag_ids": missing_refs})
    else:
        passed.append({"gate": "reference_closure"})

    if notes["anchor_binding_problems"]:
        blocking.append(
            {"gate": "anchor_binding", "items": notes["anchor_binding_problems"]}
        )
    else:
        passed.append({"gate": "anchor_binding"})

    placeholder_tags = [
        tag["canonical_id"]
        for tag in context["tags"]
        if tag.get("identity_state") == "resolved_placeholder"
    ]
    if placeholder_tags:
        warnings.append({"gate": "placeholder", "tag_ids": placeholder_tags})
    else:
        passed.append({"gate": "placeholder"})

    value_hints = {}
    for tag in semantic["tags"]:
        value_hints.setdefault(tag["value_hint"], []).append(tag["id"])
    duplicated_hints = [ids for ids in value_hints.values() if len(ids) > 1]
    if duplicated_hints:
        warnings.append({"gate": "value_hint_duplicate", "groups": duplicated_hints})

    time_like_tags = [tag for tag in semantic["tags"] if is_time_like(tag)]
    if time_like_tags and all(not tag.get("context_hint") for tag in time_like_tags):
        warnings.append(
            {
                "gate": "context_hint_sparse",
                "tag_ids": [tag["id"] for tag in time_like_tags],
            }
        )
    else:
        passed.append({"gate": "context_hint_presence"})

    for filename in ["tagging-hint.md", "assembly-hint.md", "block-summary-hint.md"]:
        content = (draft_dir / filename).read_text(encoding="utf-8")
        if "TODO" in content or len(content.splitlines()) <= 3:
            warnings.append({"gate": "hint_thin", "file": filename})
    if not any(item.get("gate") == "hint_thin" for item in warnings):
        passed.append({"gate": "hint_substance"})

    status = "failed" if blocking else ("passed_with_risks" if warnings else "passed")
    report = {
        "blocking": blocking,
        "warnings": warnings,
        "pass": passed,
        "status": status,
    }
    json_dump(run_dir / "validation-report.json", report)
    (run_dir / "audit-report.md").write_text(
        build_audit_report(context, notes, report), encoding="utf-8"
    )
    manifest["current_stage"] = 8
    json_dump(run_dir / "run-manifest.json", manifest)


def build_audit_report(context, notes, report):
    lines = [
        "# audit-report",
        "",
        "## 输入摘要",
        f"- 输入文件: `{context['manifest']['inputs'][0]['name']}`",
        f"- 选中 type: `{context['selected_type']['canonical_id']}` / {context['selected_type']['name']}",
        f"- 选中 block 数: {len(context['blocks'])}",
        f"- 选中 tag 数: {len(context['tags'])}",
        "",
        "## 自动修复摘要",
    ]
    header_repairs = context["normalized"]["header_repairs"]
    if header_repairs:
        for repair in header_repairs:
            lines.append(
                f"- header {repair['col_label']}: `{repair['raw_header']}` -> `{repair['normalized_header']}` ({repair['repair_type']})"
            )
    else:
        lines.append("- 无")
    if notes["anchor_binding_repairs"]:
        for item in notes["anchor_binding_repairs"]:
            lines.append(
                f"- {item['tag_id']}: {json.dumps(item['fixes'], ensure_ascii=False)}"
            )
    lines.extend(["", "## 身份问题摘要"])
    if context["identity"]["empty_tag_code_rows"]:
        for item in context["identity"]["empty_tag_code_rows"]:
            lines.append(
                f"- row {item['row_index']}: `{item['tag_name']}` entered recovery flow"
            )
    else:
        lines.append("- 无")
    lines.extend(["", "## 结构校验摘要", f"- status: `{report['status']}`"])
    for item in report["blocking"]:
        lines.append(f"- blocking: {json.dumps(item, ensure_ascii=False)}")
    for item in report["warnings"]:
        lines.append(f"- warning: {json.dumps(item, ensure_ascii=False)}")
    lines.extend(["", "## 未决问题摘要"])
    if notes["anchor_binding_problems"] or report["blocking"]:
        for item in notes["anchor_binding_problems"]:
            lines.append(
                f"- anchor_binding problem: {json.dumps(item, ensure_ascii=False)}"
            )
        for item in report["blocking"]:
            lines.append(f"- blocking gate: {json.dumps(item, ensure_ascii=False)}")
    else:
        lines.append("- 无")
    lines.extend(["", "## 占位符摘要"])
    placeholders = [
        tag["canonical_id"]
        for tag in context["tags"]
        if tag.get("identity_state") == "resolved_placeholder"
    ]
    lines.append(f"- placeholder tags: {placeholders if placeholders else '无'}")
    lines.extend(["", "## 类型污染检查摘要"])
    pollution = [
        item for item in report["blocking"] if item.get("gate") == "type_pollution"
    ]
    lines.append(f"- 结果: {'发现问题' if pollution else '通过'}")
    return "\n".join(lines) + "\n"


def final_handoff(args):
    run_dir = Path(args.run_dir).resolve()
    manifest = json_load(run_dir / "run-manifest.json")
    context = build_context(run_dir)
    validation = json_load(run_dir / "validation-report.json")
    if validation["blocking"]:
        raise SystemExit("blocking issues present; final handoff aborted")
    draft_dir = run_dir / "semantic-draft"
    namespace = context["identity"]["namespace"]
    final_root = Path(context["manifest"]["output_root"]) / namespace
    type_dir = final_root / "types" / context["selected_type"]["canonical_id"]
    type_dir.mkdir(parents=True, exist_ok=True)
    json_dump(
        final_root / "page-types.data.json",
        json_load(draft_dir / "page-types.data.json"),
    )
    json_dump(
        final_root / "page-types.tree.json",
        json_load(draft_dir / "page-types.tree.json"),
    )
    json_dump(
        type_dir / "page-semantic-spec.json",
        json_load(draft_dir / "page-semantic-spec.json"),
    )
    for filename in [
        "tagging-hint.md",
        "assembly-hint.md",
        "block-summary-hint.md",
        "page-summary-hint.md",
        "continuation-hint.md",
    ]:
        (type_dir / filename).write_text(
            (draft_dir / filename).read_text(encoding="utf-8"), encoding="utf-8"
        )
    (run_dir / "final-report.md").write_text(
        build_final_report(context, validation, final_root), encoding="utf-8"
    )
    manifest["current_stage"] = 9
    manifest["final_output_dir"] = str(final_root)
    json_dump(run_dir / "run-manifest.json", manifest)


def build_final_report(context, validation, final_root):
    placeholders = [
        tag["canonical_id"]
        for tag in context["tags"]
        if tag.get("identity_state") == "resolved_placeholder"
    ]
    risks = []
    if any(
        item.get("gate") == "value_hint_duplicate" for item in validation["warnings"]
    ):
        risks.append("部分 value_hint 仍存在相似模板化风险。")
    if any(item.get("gate") == "hint_thin" for item in validation["warnings"]):
        risks.append("部分 hint 文件素材有限，内容仍偏短。")
    auto_decisions = [
        "page-types.data.json 与 page-types.tree.json 目前使用同一 taxonomy 载荷，以满足同一 schema 约束。",
        "页摘要与续写提示因当前设计稿无专门素材，按规则输出空模板。",
        "空 tag编码 的时间源标签按稳定 role token 恢复为可复用 ID。",
    ]
    lines = [
        "# final-report",
        "",
        "## 处理范围",
        f"- type: `{context['selected_type']['canonical_id']}` / {context['selected_type']['name']}",
        "",
        "## 生成文件",
        f"- final dir: `{final_root}`",
        f"- `{final_root / 'page-types.data.json'}`",
        f"- `{final_root / 'page-types.tree.json'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'page-semantic-spec.json'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'tagging-hint.md'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'assembly-hint.md'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'block-summary-hint.md'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'page-summary-hint.md'}`",
        f"- `{final_root / 'types' / context['selected_type']['canonical_id'] / 'continuation-hint.md'}`",
        "",
        "## 自动决策",
    ]
    for item in auto_decisions:
        lines.append(f"- {item}")
    lines.extend(["", "## 剩余风险"])
    if risks:
        for item in risks:
            lines.append(f"- {item}")
    else:
        lines.append("- 无额外风险。")
    lines.extend(["", "## 占位符对象"])
    lines.append(f"- {placeholders if placeholders else '无'}")
    lines.extend(["", "## Validation 状态", f"- `{validation['status']}`"])
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=["0", "1", "2", "3", "4-list", "4-select", "5", "6", "7", "8", "9"],
    )
    parser.add_argument(
        "--input",
        default=str(Path(r"D:\data\save_tmp\入院记录-主诉与现病史结构化解析.xlsx")),
    )
    parser.add_argument("--mode", default="interactive")
    parser.add_argument("--run-dir", default=str(DEFAULT_RUN_DIR))
    parser.add_argument("--selected-type")
    args = parser.parse_args()

    if args.stage == "0":
        build_run_manifest(args)
        return
    if args.stage == "1":
        parse_workbook(args)
        return
    if args.stage == "2":
        normalize_workbook(args)
        return
    if args.stage == "3":
        resolve_identity(args)
        return
    if args.stage == "4-list":
        enumerate_types(args)
        return
    if args.stage == "4-select":
        select_type(args)
        return
    if args.stage == "5":
        check_existence(args)
        return
    if args.stage == "6":
        build_skeleton(args)
        return
    if args.stage == "7":
        build_semantic_draft(args)
        return
    if args.stage == "8":
        validate_outputs(args)
        return
    if args.stage == "9":
        final_handoff(args)
        return


if __name__ == "__main__":
    main()
