# audit-report

## Input Summary

- workbook: 入院记录-主诉与现病史结构化解析.xlsx
- namespace: default
- category: CATEGORY_ADMISSION_AND_INITIAL_ASSESSMENT_STAGE / 入院与初始评估阶段
- type: TYPE_ADMISSION_RECORD / 入院记录
- blocks: 10
- root tags: 75

## Automatic Fixes

- header alias fixes: namespce -> namespace, Bolck role -> Block role
- anchor alias fixes: with_type_run -> within_type_run where present
- anchor defaults: page_window.mode -> within_type_run, required -> true, self_resolution -> direction_only when source text omitted them
- row1 preserved as preamble row before header, not silently dropped
- block_start rows were also treated as inline tag carriers to avoid losing each block's first tag definition

## Identity Issues

- empty tag-code rows were retained and classified instead of being dropped
- 10 record_time_source rows were marked helper_only and excluded from root tags
- identity blocking count: 0

## Structural Validation

- status: passed
- blocking: 0
- warnings: 0
- pass: 10

## Unresolved Issues

- none

## Placeholder Summary

- none
