# normalization-report

## Header Fixes

- 'namespce' -> 'namespace' (known_alias)
- 'category_id' -> 'category_id' (exact_match)
- 'category_name' -> 'category_name' (exact_match)
- 'category_description' -> 'category_description' (exact_match)
- 'type_id' -> 'type_id' (exact_match)
- 'type_name' -> 'type_name' (exact_match)
- '一级要点' -> None (unrecognized_header)
- '主线索' -> None (unrecognized_header)
- '情景' -> '情景' (exact_match)
- '情景id' -> '情景id' (exact_match)
- '阶段' -> '阶段' (exact_match)
- '阶段id' -> '阶段id' (exact_match)
- '动作' -> '动作' (exact_match)
- '动作id' -> '动作id' (exact_match)
- 'Block' -> 'Block' (exact_match)
- 'Block id' -> 'Block id' (exact_match)
- 'Block description' -> 'Block description' (exact_match)
- 'tag名称' -> 'tag名称' (exact_match)
- 'Bolck role' -> 'Block role' (known_alias)
- 'tag编码' -> 'tag编码' (exact_match)
- 'tag定义' -> 'tag定义' (exact_match)
- 'tag anchor binding' -> 'tag anchor binding' (exact_match)
- '触发模式' -> '触发模式' (exact_match)
- '正例' -> '正例' (exact_match)
- '反例' -> '反例' (exact_match)
- '必须' -> '必须' (exact_match)
- '块摘要构造和输出组装' -> '块摘要构造和输出组装' (exact_match)
- '采集和转化规范' -> '采集和转化规范' (exact_match)
- '缺项处理' -> '缺项处理' (exact_match)
- '冲突处理' -> '冲突处理' (exact_match)

## Preamble Rows

- preserved non-tabular rows before header: [1]

## Inheritance Fill Summary

- rows with inherited context: 93 / 94

## Text Cleanup Summary

- trimmed leading/trailing whitespace only; no semantic rewrites.

## Row Classification Summary

- block_start: 10
- tag_candidate: 84
- helper_candidate: 0
- unknown: 0
- empty: 0