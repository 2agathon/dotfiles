import json
import os
import re
from collections import Counter
from datetime import date


BASE = r"D:\data\save_tmp\admission-record-spec-run"
SEM = os.path.join(BASE, "semantic-draft")


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def read_text(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


ID_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")
TYPE_RE = re.compile(r"^TYPE_[A-Z0-9_]+$")
BLOCK_RE = re.compile(r"^BLOCK_[A-Z0-9_]+$")
TAG_RE = re.compile(r"^TAG_[A-Z0-9_]+$")
SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)


def push(bucket, code, message, **extra):
    item = {"code": code, "message": message}
    item.update(extra)
    bucket.append(item)


def expect_only(obj, allowed, bucket, context):
    extra = sorted(set(obj.keys()) - set(allowed))
    if extra:
        push(
            bucket,
            "additional_properties",
            f"{context} contains unsupported keys: {extra}",
            context=context,
            keys=extra,
        )


def validate_page_types(obj, label, blocking, passed):
    expect_only(
        obj,
        [
            "version",
            "description",
            "last_updated",
            "schema_meta",
            "sources",
            "categories",
        ],
        blocking,
        label,
    )
    for req in ["version", "description", "last_updated", "categories"]:
        if req not in obj:
            push(
                blocking,
                "missing_required",
                f"{label} missing required field `{req}`.",
                file=label,
            )
    if "version" in obj and not SEMVER_RE.match(obj["version"]):
        push(
            blocking,
            "invalid_version",
            f"{label} version is not valid SemVer.",
            file=label,
        )
    if "last_updated" in obj:
        try:
            date.fromisoformat(obj["last_updated"])
        except Exception:
            push(
                blocking,
                "invalid_last_updated",
                f"{label} last_updated is not ISO date.",
                file=label,
            )
    categories = obj.get("categories") or []
    if not categories:
        push(
            blocking,
            "empty_categories",
            f"{label} categories must be non-empty.",
            file=label,
        )
    for idx, category in enumerate(categories):
        expect_only(
            category,
            [
                "id",
                "name",
                "description",
                "order",
                "deprecated",
                "replaced_by",
                "source_keys",
                "types",
            ],
            blocking,
            f"{label}.categories[{idx}]",
        )
        for req in ["id", "name", "description", "types"]:
            if req not in category:
                push(
                    blocking,
                    "missing_required",
                    f"{label}.categories[{idx}] missing `{req}`.",
                    file=label,
                )
        if not ID_RE.match(category.get("id", "")):
            push(
                blocking,
                "invalid_category_id",
                f"{label}.categories[{idx}] id is invalid.",
                file=label,
                id=category.get("id"),
            )
        if not category.get("name"):
            push(
                blocking,
                "empty_category_name",
                f"{label}.categories[{idx}] name is empty.",
                file=label,
            )
        if not category.get("description"):
            push(
                blocking,
                "empty_category_description",
                f"{label}.categories[{idx}] description is empty.",
                file=label,
            )
        types = category.get("types") or []
        if not types:
            push(
                blocking,
                "empty_types",
                f"{label}.categories[{idx}] types must be non-empty.",
                file=label,
            )
        for j, type_obj in enumerate(types):
            expect_only(
                type_obj,
                [
                    "id",
                    "name",
                    "description",
                    "aliases",
                    "deprecated",
                    "replaced_by",
                    "source_keys",
                ],
                blocking,
                f"{label}.categories[{idx}].types[{j}]",
            )
            for req in ["id", "name"]:
                if req not in type_obj:
                    push(
                        blocking,
                        "missing_required",
                        f"{label}.categories[{idx}].types[{j}] missing `{req}`.",
                        file=label,
                    )
            if not ID_RE.match(type_obj.get("id", "")):
                push(
                    blocking,
                    "invalid_type_id",
                    f"{label}.categories[{idx}].types[{j}] id is invalid.",
                    file=label,
                    id=type_obj.get("id"),
                )
            if not type_obj.get("name"):
                push(
                    blocking,
                    "empty_type_name",
                    f"{label}.categories[{idx}].types[{j}] name is empty.",
                    file=label,
                )
    if not any(
        item["code"].startswith("invalid_") or item["code"].startswith("missing_")
        for item in blocking
        if item.get("file") == label
    ):
        push(
            passed,
            "schema_page_types_ok",
            f"{label} passed structural checks.",
            file=label,
        )


def validate_page_semantic(obj, blocking, passed):
    label = "page-semantic-spec.json"
    expect_only(
        obj,
        ["version", "page_type", "action_paths", "block_types", "tags"],
        blocking,
        label,
    )
    for req in ["version", "page_type", "block_types", "tags"]:
        if req not in obj:
            push(
                blocking,
                "missing_required",
                f"{label} missing required field `{req}`.",
                file=label,
            )
    if "version" in obj and not obj["version"]:
        push(blocking, "empty_version", f"{label} version is empty.", file=label)
    page_type = obj.get("page_type") or {}
    expect_only(page_type, ["id", "name"], blocking, "page_type")
    if not TYPE_RE.match(page_type.get("id", "")):
        push(
            blocking,
            "invalid_page_type_id",
            "page_type.id is invalid.",
            file=label,
            id=page_type.get("id"),
        )
    if not page_type.get("name"):
        push(blocking, "empty_page_type_name", "page_type.name is empty.", file=label)

    tag_ids = set()
    for idx, tag in enumerate(obj.get("tags") or []):
        expect_only(
            tag,
            ["id", "name", "value_hint", "context_hint", "anchor_binding"],
            blocking,
            f"tags[{idx}]",
        )
        for req in ["id", "name", "value_hint"]:
            if req not in tag:
                push(
                    blocking,
                    "missing_required",
                    f"tags[{idx}] missing `{req}`.",
                    file=label,
                )
        tag_id = tag.get("id", "")
        if not TAG_RE.match(tag_id):
            push(
                blocking,
                "invalid_tag_id",
                f"tags[{idx}] id is invalid.",
                file=label,
                id=tag_id,
            )
        if tag_id in tag_ids:
            push(
                blocking,
                "duplicate_tag_id",
                f"Duplicate root tag id `{tag_id}`.",
                file=label,
                id=tag_id,
            )
        tag_ids.add(tag_id)
        if not tag.get("name"):
            push(blocking, "empty_tag_name", f"tags[{idx}] name is empty.", file=label)
        if not tag.get("value_hint"):
            push(
                blocking,
                "empty_value_hint",
                f"tags[{idx}] value_hint is empty.",
                file=label,
                id=tag_id,
            )
        anchor = tag.get("anchor_binding")
        if anchor is not None:
            expect_only(
                anchor,
                [
                    "target_tag_ids",
                    "page_window",
                    "direction",
                    "required",
                    "self_resolution",
                ],
                blocking,
                f"tags[{idx}].anchor_binding",
            )
            for req in ["target_tag_ids", "page_window", "direction", "required"]:
                if req not in anchor:
                    push(
                        blocking,
                        "missing_required",
                        f"tags[{idx}].anchor_binding missing `{req}`.",
                        file=label,
                        id=tag_id,
                    )
            targets = anchor.get("target_tag_ids") or []
            if not isinstance(targets, list) or not targets:
                push(
                    blocking,
                    "invalid_anchor_targets",
                    f"tags[{idx}].anchor_binding.target_tag_ids must be non-empty array.",
                    file=label,
                    id=tag_id,
                )
            else:
                for target in targets:
                    if not TAG_RE.match(target):
                        push(
                            blocking,
                            "invalid_anchor_target_id",
                            f"tags[{idx}] anchor target `{target}` is invalid.",
                            file=label,
                            id=tag_id,
                        )
            page_window = anchor.get("page_window") or {}
            expect_only(
                page_window,
                ["mode", "prev", "next"],
                blocking,
                f"tags[{idx}].anchor_binding.page_window",
            )
            mode = page_window.get("mode")
            if mode not in ["within_type_run", "bounded"]:
                push(
                    blocking,
                    "invalid_page_window_mode",
                    f"tags[{idx}] anchor page_window.mode is invalid.",
                    file=label,
                    id=tag_id,
                )
            if mode == "bounded" and (
                "prev" not in page_window or "next" not in page_window
            ):
                push(
                    blocking,
                    "bounded_window_missing_range",
                    f"tags[{idx}] bounded page_window must include prev and next.",
                    file=label,
                    id=tag_id,
                )
            if anchor.get("direction") not in [
                "before",
                "after",
                "same_segment",
                "nearby",
            ]:
                push(
                    blocking,
                    "invalid_anchor_direction",
                    f"tags[{idx}] anchor direction is invalid.",
                    file=label,
                    id=tag_id,
                )
            if not isinstance(anchor.get("required"), bool):
                push(
                    blocking,
                    "invalid_anchor_required",
                    f"tags[{idx}] anchor required must be boolean.",
                    file=label,
                    id=tag_id,
                )
            if "self_resolution" in anchor and anchor["self_resolution"] not in [
                "self_only",
                "self_first",
                "direction_first",
                "direction_only",
            ]:
                push(
                    blocking,
                    "invalid_self_resolution",
                    f"tags[{idx}] anchor self_resolution is invalid.",
                    file=label,
                    id=tag_id,
                )

    block_ids = set()
    for idx, block in enumerate(obj.get("block_types") or []):
        expect_only(
            block,
            ["id", "name", "description", "tags"],
            blocking,
            f"block_types[{idx}]",
        )
        for req in ["id", "name", "tags"]:
            if req not in block:
                push(
                    blocking,
                    "missing_required",
                    f"block_types[{idx}] missing `{req}`.",
                    file=label,
                )
        block_id = block.get("id", "")
        if not BLOCK_RE.match(block_id):
            push(
                blocking,
                "invalid_block_id",
                f"block_types[{idx}] id is invalid.",
                file=label,
                id=block_id,
            )
        if block_id in block_ids:
            push(
                blocking,
                "duplicate_block_id",
                f"Duplicate block id `{block_id}`.",
                file=label,
                id=block_id,
            )
        block_ids.add(block_id)
        if not block.get("name"):
            push(
                blocking,
                "empty_block_name",
                f"block_types[{idx}] name is empty.",
                file=label,
            )
        ref_seen = set()
        for j, ref in enumerate(block.get("tags") or []):
            expect_only(
                ref,
                ["tag_id", "role", "description"],
                blocking,
                f"block_types[{idx}].tags[{j}]",
            )
            if "tag_id" not in ref:
                push(
                    blocking,
                    "missing_required",
                    f"block_types[{idx}].tags[{j}] missing `tag_id`.",
                    file=label,
                )
                continue
            ref_id = ref["tag_id"]
            if not TAG_RE.match(ref_id):
                push(
                    blocking,
                    "invalid_block_tag_ref",
                    f"block_types[{idx}].tags[{j}] tag_id is invalid.",
                    file=label,
                    id=ref_id,
                )
            if ref_id not in tag_ids:
                push(
                    blocking,
                    "unclosed_tag_ref",
                    f"block_types[{idx}] references unknown tag `{ref_id}`.",
                    file=label,
                    block_id=block_id,
                    tag_id=ref_id,
                )
            if ref_id in ref_seen:
                push(
                    blocking,
                    "duplicate_block_tag_ref",
                    f"block_types[{idx}] has duplicate tag ref `{ref_id}`.",
                    file=label,
                    block_id=block_id,
                    tag_id=ref_id,
                )
            ref_seen.add(ref_id)

    if not any(item.get("file") == label for item in blocking):
        push(
            passed,
            "schema_page_semantic_ok",
            f"{label} passed structural checks.",
            file=label,
        )


def main():
    blocking = []
    warnings = []
    passed = []

    required_artifacts = [
        os.path.join(BASE, "run-manifest.json"),
        os.path.join(BASE, "workbook.raw.json"),
        os.path.join(BASE, "workbook.normalized.json"),
        os.path.join(BASE, "normalization-report.md"),
        os.path.join(BASE, "identity-map.json"),
        os.path.join(BASE, "identity-issues.md"),
        os.path.join(BASE, "existence-check.json"),
        os.path.join(SEM, "page-types.data.json"),
        os.path.join(SEM, "page-types.tree.json"),
        os.path.join(SEM, "page-semantic-spec.json"),
        os.path.join(SEM, "tagging-hint.md"),
        os.path.join(SEM, "assembly-hint.md"),
        os.path.join(SEM, "block-summary-hint.md"),
        os.path.join(SEM, "page-summary-hint.md"),
        os.path.join(SEM, "continuation-hint.md"),
    ]
    missing = [path for path in required_artifacts if not os.path.exists(path)]
    if missing:
        for path in missing:
            push(
                blocking,
                "missing_artifact",
                f"Missing required artifact `{path}`.",
                path=path,
            )
    else:
        push(passed, "artifacts_complete", "All required stage artifacts are present.")

    identity = load_json(os.path.join(BASE, "identity-map.json"))
    if identity.get("blocking"):
        push(
            blocking,
            "identity_blocking_present",
            "identity-map.json still contains blocking entries.",
            items=identity["blocking"],
        )
    else:
        push(passed, "identity_clear", "identity-map.json has no blocking entries.")

    data_obj = load_json(os.path.join(SEM, "page-types.data.json"))
    tree_obj = load_json(os.path.join(SEM, "page-types.tree.json"))
    semantic_obj = load_json(os.path.join(SEM, "page-semantic-spec.json"))

    validate_page_types(data_obj, "page-types.data.json", blocking, passed)
    validate_page_types(tree_obj, "page-types.tree.json", blocking, passed)
    validate_page_semantic(semantic_obj, blocking, passed)

    category_ids = [c.get("id") for c in data_obj.get("categories", [])]
    type_ids = [
        t.get("id") for c in data_obj.get("categories", []) for t in c.get("types", [])
    ]
    if any(
        not x
        for x in [semantic_obj.get("page_type", {}).get("id")] + category_ids + type_ids
    ):
        push(
            blocking, "empty_required_id", "At least one required taxonomy id is empty."
        )
    if any(not block.get("id") for block in semantic_obj.get("block_types", [])):
        push(blocking, "empty_required_id", "At least one block id is empty.")
    if any(not tag.get("id") for tag in semantic_obj.get("tags", [])):
        push(blocking, "empty_required_id", "At least one root tag id is empty.")
    for block in semantic_obj.get("block_types", []):
        for ref in block.get("tags", []):
            if not ref.get("tag_id"):
                push(
                    blocking,
                    "empty_required_id",
                    f"Block `{block.get('id')}` has empty tag ref id.",
                    block_id=block.get("id"),
                )

    semantic_tag_ids = {
        tag["id"] for tag in semantic_obj.get("tags", []) if tag.get("id")
    }
    identity_tag_ids = {
        tag["canonical_id"]
        for tag in identity.get("tags", [])
        if tag.get("identity_state")
        in ["resolved_explicit", "resolved_recovered", "resolved_placeholder"]
    }
    if semantic_tag_ids != identity_tag_ids:
        push(
            blocking,
            "identity_result_mismatch",
            "Root tag set differs between identity-map.json and semantic-draft page-semantic-spec.json.",
            identity_only=sorted(identity_tag_ids - semantic_tag_ids),
            semantic_only=sorted(semantic_tag_ids - identity_tag_ids),
        )
    else:
        push(
            passed,
            "identity_result_match",
            "Root tag ids are consistent between identity map and semantic draft.",
        )

    placeholders = [
        tag["canonical_id"]
        for tag in identity.get("tags", [])
        if tag.get("identity_state") == "resolved_placeholder"
    ]
    if placeholders:
        push(
            warnings,
            "placeholder_in_final",
            "Resolved placeholders entered semantic draft.",
            tag_ids=placeholders,
        )
    else:
        push(
            passed,
            "no_placeholders",
            "No resolved_placeholder tags entered semantic draft.",
        )

    value_hints = [tag.get("value_hint", "") for tag in semantic_obj.get("tags", [])]
    duplicates = [
        hint for hint, cnt in Counter(value_hints).items() if hint and cnt > 1
    ]
    if duplicates:
        push(
            warnings,
            "value_hint_duplicates",
            "Some value_hint texts are duplicated across tags.",
            duplicate_count=len(duplicates),
        )
    else:
        push(
            passed,
            "value_hint_diverse",
            "No exact duplicate value_hint texts detected.",
        )

    obvious_context_tags = [
        tag
        for tag in semantic_obj.get("tags", [])
        if any(
            x in tag.get("name", "")
            for x in ["时间", "日期", "患者", "诊断", "家族", "过敏"]
        )
    ]
    non_empty_context_tags = [
        tag for tag in obvious_context_tags if tag.get("context_hint")
    ]
    if obvious_context_tags and not non_empty_context_tags:
        push(
            warnings,
            "context_hint_sparse",
            "Obvious time/role tags exist but context_hint is empty for all of them.",
        )
    else:
        push(
            passed,
            "context_hint_present",
            "Context hints exist for at least some ambiguous time/role tags.",
        )

    for hint_name in ["tagging-hint.md", "assembly-hint.md", "block-summary-hint.md"]:
        text = read_text(os.path.join(SEM, hint_name))
        if "TODO" in text and len(text.splitlines()) <= 3:
            push(
                warnings,
                "thin_hint",
                f"{hint_name} is still an empty template.",
                file=hint_name,
            )
    if not any(item["code"] == "thin_hint" for item in warnings):
        push(
            passed,
            "hint_materialized",
            "Primary hint files contain materialized content.",
        )

    status = (
        "failed" if blocking else ("passed_with_warnings" if warnings else "passed")
    )
    report = {
        "status": status,
        "blocking": blocking,
        "warnings": warnings,
        "pass": passed,
    }
    with open(os.path.join(BASE, "validation-report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    audit_lines = [
        "# audit-report",
        "",
        "## Input Summary",
        "",
        "- workbook: 入院记录-主诉与现病史结构化解析.xlsx",
        f"- namespace: {identity['namespace']['canonical_id']}",
        f"- category: {identity['category']['canonical_id']} / {identity['category']['name']}",
        f"- type: {identity['type']['canonical_id']} / {identity['type']['name']}",
        f"- blocks: {len(identity.get('blocks', []))}",
        f"- root tags: {len(identity.get('tags', []))}",
        "",
        "## Automatic Fixes",
        "",
        "- header alias fixes: namespce -> namespace, Bolck role -> Block role",
        "- anchor alias fixes: with_type_run -> within_type_run where present",
        "- anchor defaults: page_window.mode -> within_type_run, required -> true, self_resolution -> direction_only when source text omitted them",
        "- row1 preserved as preamble row before header, not silently dropped",
        "- block_start rows were also treated as inline tag carriers to avoid losing each block's first tag definition",
        "",
        "## Identity Issues",
        "",
        "- empty tag-code rows were retained and classified instead of being dropped",
        "- 10 record_time_source rows were marked helper_only and excluded from root tags",
        f"- identity blocking count: {len(identity.get('blocking', []))}",
        "",
        "## Structural Validation",
        "",
        f"- status: {status}",
        f"- blocking: {len(blocking)}",
        f"- warnings: {len(warnings)}",
        f"- pass: {len(passed)}",
        "",
        "## Unresolved Issues",
        "",
    ]
    if blocking or warnings:
        for item in blocking:
            audit_lines.append(f"- BLOCKING {item['code']}: {item['message']}")
        for item in warnings:
            audit_lines.append(f"- WARNING {item['code']}: {item['message']}")
    else:
        audit_lines.append("- none")
    audit_lines += ["", "## Placeholder Summary", ""]
    if placeholders:
        for tag_id in placeholders:
            audit_lines.append(f"- {tag_id}")
    else:
        audit_lines.append("- none")
    with open(os.path.join(BASE, "audit-report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(audit_lines) + "\n")


if __name__ == "__main__":
    main()
