import json
import os
import re


BASE = r"D:\data\save_tmp\admission-record-spec-run"


def load_json(name):
    path = os.path.join(BASE, name)
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def dump_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def write_text(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def clean_block_desc(text, block_name, tag_names):
    text = (text or "").strip()
    if not text:
        dims = "、".join(tag_names[:6]) if tag_names else "相关语义信息"
        return f"{block_name}块用于表达与{block_name}相关的核心信息，覆盖{dims}等语义维度。"
    for bad in [
        "按时间链合并",
        "阴性症状独立成尾句",
        "超过字数时拆分",
        "缺项时",
        "冲突时",
    ]:
        text = text.replace(bad, "")
    return re.sub(r"\s+", " ", text).strip(" ，；;")


def synth_value_hint(tag, row):
    fields = row["normalized_fields"]
    definition = (fields.get("tag定义") or tag["name"] or "").strip()
    trigger = (fields.get("触发模式") or "").strip()
    negative = (fields.get("反例") or "").strip()
    required = (fields.get("必须") or "").strip()

    sent = [definition if definition else f"抓取与{tag['name']}对应的稳定表达。"]
    if trigger:
        sent.append(
            f"优先识别原文中明确指向该语义的表达，重点关注{trigger.rstrip('。；;')}。"
        )
    if negative:
        if any(
            x in negative
            for x in ["未提及", "未说", "无法", "无明显", "缺如", "未见", "未及"]
        ):
            sent.append("原文未提供稳定可判定值时不打本标签。")
        else:
            sent.append(
                "与本标签语义边界不一致、仅构成其他标签取值或不能稳定确认时不打本标签。"
            )
    else:
        sent.append("仅在原文存在稳定可落标签值时命中，语义边界不清时不打。")

    if required == "是":
        sent.append("输出单值，原文无明确表述时不打本标签。")
    elif required == "否":
        sent.append("输出单值，无值时可缺省。")
    else:
        sent.append("输出单值，并对时间、部位或程度等可规范化内容做轻量规范化。")
    return "".join(sent)


def synth_context_hint(tag, row):
    name = tag["name"] or ""
    definition = row["normalized_fields"].get("tag定义") or ""
    text = f"{name} {definition}"
    if "记录时间" in text:
        if "报告" in text:
            return "明确这是当前块对应的报告时间，而非其他就诊或书写时间。"
        return "明确这是当前块对应的记录时间，而非既往时间或其他事件时间。"
    if any(k in text for k in ["起病时间", "持续时间", "入院日期", "报告时间"]):
        return "补足该时间值对应的事件类型，避免与其他时间类标签混淆。"
    if any(k in text for k in ["患者信息", "家族史", "个人史", "过敏史"]):
        return "补足该值所指向的对象范围，确保断言的是当前患者的对应背景信息。"
    if any(k in text for k in ["诊断", "初步诊断"]):
        return "明确该值表达的是当前就诊阶段形成的诊断结论。"
    return None


def parse_anchor(raw):
    if not raw or not str(raw).strip():
        return None, []
    text = str(raw)
    repairs = []

    fixed = text.replace("with_type_run", "within_type_run")
    if fixed != text:
        repairs.append({"from": text, "to": fixed, "repair_type": "known_alias"})
        text = fixed

    target_match = re.search(r"target_tag_ids\s*:\s*\[(.*?)\]", text, re.S)
    targets = []
    if target_match:
        targets = [
            x.strip().strip('"').strip("'")
            for x in target_match.group(1).split(",")
            if x.strip()
        ]

    mode_match = re.search(
        r"page_window\.mode\s*:\s*\{?\s*\"?([A-Za-z_]+)\"?\s*\}?", text
    )
    mode = mode_match.group(1) if mode_match else "within_type_run"
    if not mode_match:
        repairs.append(
            {
                "from": None,
                "to": "within_type_run",
                "repair_type": "default_page_window_mode",
            }
        )

    direction_match = re.search(r"direction\s*:\s*\"?([A-Za-z_]+)\"?", text)
    direction = direction_match.group(1) if direction_match else None

    required_match = re.search(r"required\s*:\s*(true|false)", text, re.I)
    required = required_match.group(1).lower() == "true" if required_match else True
    if not required_match:
        repairs.append({"from": None, "to": True, "repair_type": "default_required"})

    self_match = re.search(r"self_resolution\s*:\s*\"?([A-Za-z_]+)\"?", text)
    self_resolution = self_match.group(1) if self_match else "direction_only"
    if not self_match:
        repairs.append(
            {
                "from": None,
                "to": "direction_only",
                "repair_type": "default_self_resolution",
            }
        )

    obj = {
        "target_tag_ids": targets,
        "page_window": {"mode": mode},
        "required": required,
        "self_resolution": self_resolution,
    }
    if direction is not None:
        obj["direction"] = direction
    return obj, repairs


def build_empty_template(type_name, title, todo):
    return f"# {type_name} · {title}\n\n<!-- TODO: {todo} -->\n"


def main():
    ident = load_json("identity-map.json")
    norm = load_json("workbook.normalized.json")

    skeleton_dir = os.path.join(BASE, "skeleton")
    semantic_dir = os.path.join(BASE, "semantic-draft")
    os.makedirs(skeleton_dir, exist_ok=True)
    os.makedirs(semantic_dir, exist_ok=True)

    rows_by_index = {row["row_index"]: row for row in norm["rows"]}
    root_tags = {tag["canonical_id"]: tag for tag in ident["tags"]}

    block_types = []
    for block in ident["blocks"]:
        block_types.append(
            {
                "id": block["canonical_id"],
                "name": block["name"],
                "description": "",
                "tags": [
                    (
                        {"tag_id": ref["tag_id"], "role": ref.get("role")}
                        if ref.get("role")
                        else {"tag_id": ref["tag_id"]}
                    )
                    for ref in block["tag_refs"]
                ],
            }
        )

    taxonomy_type = {
        "id": ident["type"]["canonical_id"],
        "name": ident["type"]["name"],
    }

    page_types_data = {
        "version": "1.0.0",
        "description": f"{ident['namespace']['canonical_id']} namespace taxonomy generated from workbook run {ident['type']['canonical_id']}.",
        "last_updated": "2026-04-01",
        "categories": [
            {
                "id": ident["category"]["canonical_id"],
                "name": ident["category"]["name"],
                "description": ident["category"]["description"],
                "types": [taxonomy_type],
            }
        ],
    }

    page_types_tree = {
        "version": "1.0.0",
        "description": f"{ident['namespace']['canonical_id']} namespace taxonomy tree generated from workbook run {ident['type']['canonical_id']}.",
        "last_updated": "2026-04-01",
        "categories": [
            {
                "id": ident["category"]["canonical_id"],
                "name": ident["category"]["name"],
                "description": ident["category"]["description"],
                "types": [taxonomy_type],
            }
        ],
    }

    page_semantic = {
        "version": "1.1.0",
        "page_type": {
            "id": ident["type"]["canonical_id"],
            "name": ident["type"]["name"],
        },
        "block_types": block_types,
        "tags": [
            {"id": tag["canonical_id"], "name": tag["name"]} for tag in ident["tags"]
        ],
    }

    for outdir in [skeleton_dir, semantic_dir]:
        dump_json(os.path.join(outdir, "page-types.data.json"), page_types_data)
        dump_json(os.path.join(outdir, "page-types.tree.json"), page_types_tree)
        dump_json(os.path.join(outdir, "page-semantic-spec.json"), page_semantic)

        write_text(
            os.path.join(outdir, "tagging-hint.md"),
            build_empty_template(
                ident["type"]["name"],
                "段打标处理指导",
                "当前设计稿未提供专门的段打标补充规则",
            ),
        )
        write_text(
            os.path.join(outdir, "assembly-hint.md"),
            build_empty_template(
                ident["type"]["name"],
                "块组装处理指导",
                "当前设计稿未提供专门的块组装规则",
            ),
        )
        write_text(
            os.path.join(outdir, "block-summary-hint.md"),
            build_empty_template(
                ident["type"]["name"],
                "块摘要生成指导",
                "当前设计稿未提供专门的块摘要规则",
            ),
        )
        write_text(
            os.path.join(outdir, "page-summary-hint.md"),
            build_empty_template(
                ident["type"]["name"],
                "页摘要生成指导",
                "当前设计稿未提供专门的页摘要规则",
            ),
        )
        write_text(
            os.path.join(outdir, "continuation-hint.md"),
            build_empty_template(
                ident["type"]["name"], "续写判定提示", "当前设计稿未提供专门的续写规则"
            ),
        )

    anchor_repairs = []
    for block_obj, block in zip(page_semantic["block_types"], ident["blocks"]):
        tag_names = [
            root_tags[ref["tag_id"]]["name"]
            for ref in block["tag_refs"]
            if ref["tag_id"] in root_tags
        ]
        block_obj["description"] = clean_block_desc(
            block["description_source"], block["name"], tag_names
        )

    for tag in page_semantic["tags"]:
        source_row = min(root_tags[tag["id"]]["source_rows"])
        row = rows_by_index[source_row]
        tag["value_hint"] = synth_value_hint(tag, row)
        context_hint = synth_context_hint(tag, row)
        if context_hint is not None:
            tag["context_hint"] = context_hint
        anchor_binding, repairs = parse_anchor(
            row["normalized_fields"].get("tag anchor binding")
        )
        if anchor_binding is not None:
            tag["anchor_binding"] = anchor_binding
        for repair in repairs:
            anchor_repairs.append(
                {"tag_id": tag["id"], "row_index": source_row, **repair}
            )

    dump_json(os.path.join(semantic_dir, "page-semantic-spec.json"), page_semantic)

    tag_rows = [rows_by_index[min(tag["source_rows"])] for tag in ident["tags"]]

    boundary_rules = []
    tagging_rules = []
    for row in tag_rows:
        name = row["normalized_fields"].get("tag名称") or ""
        negative = (row["normalized_fields"].get("反例") or "").strip()
        transform = (row["normalized_fields"].get("采集和转化规范") or "").strip()
        if negative and not any(
            x in negative for x in ["未提及", "未说", "无法", "未见"]
        ):
            boundary_rules.append(
                f"- `{name}` 只在语义边界稳定时命中，避免把仅用于说明其他标签、否定背景或无稳定取值的表达误打到本标签。"
            )
        if transform and all(
            x not in transform for x in ["组装", "摘要", "冲突", "缺项"]
        ):
            tagging_rules.append(
                f"- `{name}` 在当前段内完成轻量规范化，优先保留可直接落标签的稳定表达，避免把重复噪声或修饰性碎片并入值本身。"
            )

    tagging = [f"# {ident['type']['name']} · 段打标处理指导", ""]
    if boundary_rules or tagging_rules:
        if boundary_rules:
            tagging += ["## 易混淆边界", ""] + boundary_rules[:12] + [""]
        if tagging_rules:
            tagging += ["## 段内处理规则", ""] + tagging_rules[:12] + [""]
    else:
        tagging += ["<!-- TODO: 当前设计稿未提供专门的段打标补充规则 -->", ""]
    write_text(
        os.path.join(semantic_dir, "tagging-hint.md"),
        "\n".join(tagging).rstrip() + "\n",
    )

    assembly = [f"# {ident['type']['name']} · 块组装处理指导", ""]
    assembly_has = False
    for title, col in [
        ("采集与规范化", "采集和转化规范"),
        ("缺项处理", "缺项处理"),
        ("冲突处理", "冲突处理"),
    ]:
        lines = []
        for row in norm["rows"]:
            value = (row["normalized_fields"].get(col) or "").strip()
            if value:
                owner = row["normalized_fields"].get("Block") or row[
                    "normalized_fields"
                ].get("tag名称")
                lines.append(f"- `{owner}`: {value.replace(chr(10), ' ')}")
        if lines:
            assembly_has = True
            assembly += [f"## {title}", ""] + lines + [""]
    if not assembly_has:
        assembly += ["<!-- TODO: 当前设计稿未提供专门的块组装规则 -->", ""]
    write_text(
        os.path.join(semantic_dir, "assembly-hint.md"),
        "\n".join(assembly).rstrip() + "\n",
    )

    block_summary = [f"# {ident['type']['name']} · 块摘要生成指导", ""]
    main = []
    supplement = []
    for row in norm["rows"]:
        summary = (row["normalized_fields"].get("块摘要构造和输出组装") or "").strip()
        if summary:
            main.append(
                f"- `{row['normalized_fields'].get('Block')}`: {summary.replace(chr(10), ' ')}"
            )
        for col in ["采集和转化规范", "缺项处理", "冲突处理"]:
            value = (row["normalized_fields"].get(col) or "").strip()
            if value and any(k in value for k in ["摘要", "尾句", "字数", "输出"]):
                owner = row["normalized_fields"].get("Block") or row[
                    "normalized_fields"
                ].get("tag名称")
                supplement.append(
                    f"- `{owner}` / `{col}`: {value.replace(chr(10), ' ')}"
                )
    if main or supplement:
        if main:
            block_summary += ["## 摘要重点", ""] + main + [""]
        if supplement:
            block_summary += ["## 补充约束", ""] + supplement[:20] + [""]
    else:
        block_summary += ["<!-- TODO: 当前设计稿未提供专门的块摘要规则 -->", ""]
    write_text(
        os.path.join(semantic_dir, "block-summary-hint.md"),
        "\n".join(block_summary).rstrip() + "\n",
    )

    dump_json(os.path.join(BASE, "anchor-binding-repairs.json"), anchor_repairs)


if __name__ == "__main__":
    main()
