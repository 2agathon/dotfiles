import json
import os
import shutil


BASE = r"D:\data\save_tmp\admission-record-spec-run"
SEM = os.path.join(BASE, "semantic-draft")
FINAL = os.path.join(BASE, "final")


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def copy_file(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)


def main():
    report = load_json(os.path.join(BASE, "validation-report.json"))
    if report.get("blocking"):
        raise SystemExit(
            "Validation contains blocking items; final handoff is not allowed."
        )

    identity = load_json(os.path.join(BASE, "identity-map.json"))
    semantic = load_json(os.path.join(SEM, "page-semantic-spec.json"))
    namespace = identity["namespace"]["canonical_id"]
    type_id = semantic["page_type"]["id"]

    final_namespace_dir = os.path.join(FINAL, namespace)
    final_type_dir = os.path.join(final_namespace_dir, "types", type_id)
    os.makedirs(final_type_dir, exist_ok=True)

    copy_file(
        os.path.join(SEM, "page-types.data.json"),
        os.path.join(final_namespace_dir, "page-types.data.json"),
    )
    copy_file(
        os.path.join(SEM, "page-types.tree.json"),
        os.path.join(final_namespace_dir, "page-types.tree.json"),
    )
    copy_file(
        os.path.join(SEM, "page-semantic-spec.json"),
        os.path.join(final_type_dir, "page-semantic-spec.json"),
    )
    for name in [
        "tagging-hint.md",
        "assembly-hint.md",
        "block-summary-hint.md",
        "page-summary-hint.md",
        "continuation-hint.md",
    ]:
        copy_file(os.path.join(SEM, name), os.path.join(final_type_dir, name))

    final_report = (
        "\n".join(
            [
                "# final-report",
                "",
                "## Processed Types",
                "",
                f"- {type_id} / {semantic['page_type']['name']}",
                "",
                "## Generated Files",
                "",
                f"- {namespace}/page-types.data.json",
                f"- {namespace}/page-types.tree.json",
                f"- {namespace}/types/{type_id}/page-semantic-spec.json",
                f"- {namespace}/types/{type_id}/tagging-hint.md",
                f"- {namespace}/types/{type_id}/assembly-hint.md",
                f"- {namespace}/types/{type_id}/block-summary-hint.md",
                f"- {namespace}/types/{type_id}/page-summary-hint.md",
                f"- {namespace}/types/{type_id}/continuation-hint.md",
                "",
                "## Automatic Decisions",
                "",
                "- inferred a single detected type and processed it directly without user interruption",
                "- treated row1 as workbook preamble, not data header",
                "- treated block_start rows as also carrying inline first-tag definitions",
                "- classified 10 empty tag-code record_time_source rows as helper_only rather than root tags",
                "- normalized header aliases and anchor alias/default fields during staged parsing",
                "",
                "## Remaining Risks",
                "",
                "- no schema blocking remained at handoff time",
                "- inline tag extraction on block_start rows is an explicit workflow deviation recorded in audit-report.md",
                "",
                "## Placeholder Objects",
                "",
                "- none",
            ]
        )
        + "\n"
    )

    with open(os.path.join(BASE, "final-report.md"), "w", encoding="utf-8") as f:
        f.write(final_report)


if __name__ == "__main__":
    main()
