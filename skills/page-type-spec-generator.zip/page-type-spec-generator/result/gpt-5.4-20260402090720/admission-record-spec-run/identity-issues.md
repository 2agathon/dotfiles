# identity-issues

## Empty tag code rows

- row 8: 入院日期 / record_time_source -> helper_only
- row 24: 入院日期 / record_time_source -> helper_only
- row 40: 入院日期 / record_time_source -> helper_only
- row 51: 入院日期 / record_time_source -> helper_only
- row 57: 入院日期 / record_time_source -> helper_only
- row 65: 入院日期 / record_time_source -> helper_only
- row 70: 入院日期 / record_time_source -> helper_only
- row 81: 入院日期 / record_time_source -> helper_only
- row 88: 报告时间 / record_time_source -> helper_only
- row 96: 报告时间 / record_time_source -> helper_only

## Inline tag extraction from block_start rows

- rows treated as both block starts and inline tag carriers: [3, 10, 26, 42, 53, 59, 67, 72, 84, 90]
- // DEVIATION: lock_start rows in this workbook also carry the first tag definition of each block; otherwise first tags would be dropped by Stage 3.

## Identity conflicts

- none

## Placeholder generation

- none