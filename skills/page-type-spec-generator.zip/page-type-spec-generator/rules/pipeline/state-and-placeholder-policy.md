# 状态与占位策略

## 总规则

1. 所有进入最终结果的必填 ID 字段都不得为空字符串。
2. 必填对象不能留空时，必须在“稳定占位符”与“阻断”之间二选一。
3. `blocked` 状态不得进入 `skeleton/` 之后的阶段。
4. 占位不是静默容错，必须可识别、可复用、可记录。
5. 具名对象不得因编码缺失而直接降为 `helper_only`。

## 身份状态

只允许以下身份状态：

1. `resolved_explicit`
2. `resolved_recovered`
3. `resolved_placeholder`
4. `helper_only`
5. `invalid_or_noise`
6. `blocked`

## 身份状态含义

### `resolved_explicit`

含义：

1. 对象有显式原始 ID
2. 规范化后得到稳定 canonical id

### `resolved_recovered`

含义：

1. 原始 ID 缺失或不可直接使用
2. 但可通过显式同源对象继承，或通过稳定语义生成 canonical id

### `resolved_placeholder`

含义：

1. 对象必须存在
2. 但当前输入不足以形成正常 canonical id
3. 因此生成稳定占位符 id

### `helper_only`

含义：

1. 行只承担 block 内辅助作用
2. 不进入根级对象集合
3. 不得用于承接具名且带语义载荷的对象

### `invalid_or_noise`

含义：

1. 不构成可消费对象
2. 仅保留回溯信息

### `blocked`

含义：

1. 存在关键歧义或缺失
2. 当前规则无法安全继续

## 具名空编码行策略

### 默认规则

满足以下条件的行，视为具名空编码行：

1. `tag名称` 非空
2. 位于标签定义区
3. `tag编码` 为空

具名空编码行必须按以下顺序处理：

1. 先尝试 `resolved_recovered`
2. 若无法恢复且对象必须存在，则进入 `resolved_placeholder`
3. 若存在真实多候选歧义或结构冲突，则进入 `blocked`

### 禁止规则

具名空编码行不得：

1. 直接丢弃
2. 直接输出空字符串 ID
3. 仅因存在 `role` 就降为 `helper_only`

## 内容状态

只允许以下内容状态：

1. `materialized`
2. `deferred_template`
3. `omitted`
4. `blocked`

## 内容状态含义

### `materialized`

含义：

1. 已生成实质内容

### `deferred_template`

含义：

1. 当前输出文件必须存在
2. 但设计稿无足够素材
3. 因此输出空模板或 TODO 模板

### `omitted`

含义：

1. 当前字段是可选字段
2. 当前无素材或无歧义
3. 因此直接省略

### `blocked`

含义：

1. 当前内容缺失关键条件
2. 不得继续进入最终结果

## 最终结果准入规则

### 允许进入最终结果

1. `resolved_explicit`
2. `resolved_recovered`
3. `resolved_placeholder`
4. `materialized`
5. `deferred_template`
6. `omitted`（仅对可选字段）

说明：

1. `resolved_placeholder` 允许进入最终结果，但必须在报告中显式列出。

### 禁止进入最终结果

1. 空字符串 ID
2. `blocked`
3. `helper_only`
4. `invalid_or_noise`

## `helper_only` 准入条件

只有同时满足以下条件时，才允许使用 `helper_only`：

1. 当前对象不应进入根级集合
2. 当前行不构成独立可消费标签
3. 当前问题不是编码缺失，而是对象职责本身仅为辅助

只要任一条件不满足，不得使用 `helper_only`。

## 占位符规则

### 1. 何时生成占位符

满足以下条件时，必须生成稳定占位符，而不是返回空字符串：

1. 当前对象按流程必须存在
2. 原始输入不足以形成正常 canonical id
3. 当前问题不是“多候选歧义”，而是“缺稳定命名信号”

### 2. 何时不得生成占位符

满足以下任一条件时，不得用占位符掩盖问题：

1. 多个候选身份同样合理
2. 当前对象本身就不应进入根级集合
3. 当前问题属于结构冲突，而非命名缺失

### 2.1 何时优先占位而不是阻断

满足以下条件时，优先使用 `resolved_placeholder`：

1. 当前对象按流程必须存在
2. 当前缺的是稳定命名信号
3. 当前不存在多候选歧义
4. 占位不会改变对象是否应进入根级集合的判断

### 2.2 何时优先阻断而不是占位

满足以下任一条件时，必须使用 `blocked`：

1. 多个候选身份同样合理
2. 上游身份本身未稳定
3. 同一对象可能对应多个不同 canonical id
4. 当前对象是否应存在本身就不明确

### 3. 占位符必须记录

生成占位符时，必须记录：

1. 占位符 id
2. 占位原因
3. 来源行号

## hint 文件规则

1. 若文件必须输出但无素材，使用 `deferred_template`
2. 若字段是可选字段且无素材，使用 `omitted`
3. 不得把“无素材”误当成 `blocked`

## 失败信号

以下情况说明状态策略未被执行：

1. 空字符串 ID 进入最终结果
2. `blocked` 对象进入 `skeleton/` 之后阶段
3. 应输出模板的文件被静默省略
4. 应省略的可选字段被错误占位
5. 具名空编码行被直接降为 `helper_only`
